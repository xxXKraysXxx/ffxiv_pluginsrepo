using System.Numerics;
namespace Dalamud.Game.ClientState.Conditions { public enum ConditionFlag { BoundByDuty, BetweenAreas, WaitingForDutyFinder } }
namespace Dalamud.Game.ClientState.Objects.Enums { public enum ObjectKind { Pc } }
namespace Dalamud.Bindings.ImGui {
    public static class ImGui {
        public static bool Button(string s) => false;
        public static void SameLine() { }
        public static void TextUnformatted(string s) { }
        public static void Checkbox(string s, ref bool b) { }
        public static void SliderFloat(string s, ref float v, float min, float max) { }
        public static void SliderInt(string s, ref int v, int min, int max) { }
    }
}
namespace Dalamud.Interface.Utility.Raii { public static class ImRaii { public static IDisposable PushIndent() => new Scope(); private class Scope : IDisposable { public void Dispose() { } } } }
namespace Dalamud.Interface.Windowing {
    public class Window {
        public Window(string name) { }
        public bool ShowCloseButton, RespectCloseHotkey, IsOpen;
        public virtual void PreOpenCheck() { }
        public virtual void Draw() { }
    }
}
namespace Dalamud.Utility.Signatures { }
namespace Dalamud.Hooking {
    public class Hook<T>(T original) : IDisposable where T : Delegate {
        public T Original = original;
        public nint Address => 0;
        public void Enable() { }
        public void Dispose() { }
    }
}
namespace FFXIVClientStructs.FFXIV.Client.Sound { }
namespace FFXIVClientStructs.FFXIV.Client.Game { public enum ActionType : byte { Action = 1, Item = 2 } }
namespace FFXIVClientStructs.FFXIV.Client.Game.Object { public struct GameObjectId { public ulong Value; } public struct GameObject { public Vector3 Position; } }
namespace FFXIVClientStructs.FFXIV.Client.Game.Character {
    public struct Character { public Object.GameObject GameObject; }
    public unsafe static class ActionEffectHandler {
        public struct Header { public byte ActionType; public uint ActionId; }
        public struct TargetEffects { }
        public static class MemberFunctionPointers { public static nint Receive => 0; }
        public static class Delegates { public unsafe delegate void Receive(uint id, Character* caster, Vector3* pos, Header* header, TargetEffects* effects, Object.GameObjectId* targets); }
    }
}
namespace FFXIVClientStructs.FFXIV.Client.System.Framework { public unsafe struct Framework { public float FrameDeltaTime; public static Framework* Instance() => null; } }
namespace FFXIVClientStructs.FFXIV.Component.GUI {
    public enum AtkLoadState { Unloaded, Loaded }
    public struct UldManager { public AtkLoadState LoadedState; }
    public struct AtkUnitBase { public bool IsVisible; public UldManager UldManager; }
}
namespace FFXIVClientStructs.FFXIV.Client.UI {
    public unsafe struct RaptureAtkUnitManager {
        public static nint Address, AddonAddress;
        public static int Lookups;
        public static RaptureAtkUnitManager* Instance() => (RaptureAtkUnitManager*)Address;
        public Component.GUI.AtkUnitBase* GetAddonByName(string name) { if (name != "_FGSEliminated") throw new Exception(name); ++Lookups; return (Component.GUI.AtkUnitBase*)AddonAddress; }
    }
}
namespace vfallguy {
    public static class Service {
        public static Conditions Condition = new();
        public static ClientState ClientState = new();
        public static Objects ObjectTable = new();
        public static Logger Log = new();
        public static Hooks Hook = new();
    }
    public class Conditions {
        private readonly HashSet<Dalamud.Game.ClientState.Conditions.ConditionFlag> flags = [];
        public bool this[Dalamud.Game.ClientState.Conditions.ConditionFlag flag] { get => flags.Contains(flag); set { if (value) flags.Add(flag); else flags.Remove(flag); } }
    }
    public class ClientState { public uint TerritoryType; }
    public class Player { public Vector3 Position; public Dalamud.Game.ClientState.Objects.Enums.ObjectKind ObjectKind; }
    public class Objects : List<Player> { public Player? LocalPlayer; }
    public class Logger { public void Debug(string s) { } public void Information(string s) { } }
    public class Hooks {
        public void InitializeFromAttributes(object o) { }
        public Dalamud.Hooking.Hook<T> HookFromAddress<T>(nint a, T d) where T : Delegate => new(d);
        public Dalamud.Hooking.Hook<T> HookFromSignature<T>(string s, T d) where T : Delegate => new(d);
    }
    public class AutoJoinLeave : IDisposable {
        public bool Idle = true;
        public int Leaves, Registrations;
        public void RegisterForDuty() { ++Registrations; Idle = false; }
        public void LeaveDuty() { ++Leaves; Idle = false; }
        public void Update() { }
        public void Dispose() { }
    }
    public class DebugDrawer {
        public void Update() { }
        public void DrawWorldPrimitives() { }
        public void DrawWorldLine(Vector3 a, Vector3 b, uint col) { }
        public void DrawWorldText(Vector3 a, uint col, string s) { }
    }
    public static class Geom { public static Vector3 NormalizedXZ(this Vector3 p) => p; }
    public class Map : IDisposable {
        public const float InvSpeed = 1;
        public Vector3 PlayerPos;
        public int PathSkip;
        public List<(DateTime StartMoveAt, Vector3 Dest)> Path = [];
        public List<AOE> AOEs = [];
        public string Strats() => "";
        public void Update() { }
        public void Dispose() { }
    }
    public class Map3 : Map { public Map3(GameEvents e) { } }
    public class AOE {
        public DateTime NextActivation;
        public Vector3 Origin;
        public (float, float) Intersect(Vector3 p, Vector3 d) => (0, 1);
        public bool Contains(Vector3 p) => false;
        public float ActivatesBetween(DateTime now, float a, float b) => 0;
        public void Draw(DebugDrawer d, uint col) { }
    }
}
