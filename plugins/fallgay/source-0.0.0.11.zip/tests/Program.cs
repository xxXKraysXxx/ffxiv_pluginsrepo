using System.Numerics;
using System.Reflection;
using System.Runtime.CompilerServices;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Hooking;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Character;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using vfallguy;

unsafe class Program {
    private static int checks;
    private static void Assert(bool ok, string name) { if (!ok) throw new Exception(name); ++checks; Console.WriteLine("PASS " + name); }
    private static FieldInfo Field(Type t, string name) => t.GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!;
    public static void Main() {
        var window = (MainWindow)RuntimeHelpers.GetUninitializedObject(typeof(MainWindow));
        var automation = new AutoJoinLeave();
        Field(typeof(MainWindow), "_automation").SetValue(window, automation);
        Field(typeof(MainWindow), "_autoLeaveIfLost").SetValue(window, true);
        var update = typeof(MainWindow).GetMethod("UpdateAutoLeaveLost", BindingFlags.Instance | BindingFlags.NonPublic)!;
        var manager = new RaptureAtkUnitManager();
        var addon = new AtkUnitBase { IsVisible = true, UldManager = new() { LoadedState = AtkLoadState.Loaded } };
        RaptureAtkUnitManager.Address = (nint)(&manager);
        RaptureAtkUnitManager.AddonAddress = (nint)(&addon);
        void Tick() => update.Invoke(window, null);
        Service.ClientState.TerritoryType = 1197;
        Service.Condition[ConditionFlag.BoundByDuty] = true;
        Tick(); Assert(automation.Leaves == 0 && RaptureAtkUnitManager.Lookups == 0, "no leave or addon access outside Fall Guys duty");
        Service.ClientState.TerritoryType = 1165;
        Service.Condition[ConditionFlag.BoundByDuty] = false;
        Tick(); Assert(automation.Leaves == 0, "no leave while not bound by duty");
        Service.Condition[ConditionFlag.BoundByDuty] = true;
        Service.Condition[ConditionFlag.BetweenAreas] = true;
        Tick(); Assert(automation.Leaves == 0, "no leave while changing zones");
        Service.Condition[ConditionFlag.BetweenAreas] = false;
        Field(typeof(MainWindow), "_autoLeaveIfLost").SetValue(window, false);
        Tick(); Assert(automation.Leaves == 0, "disabled auto leave does nothing");
        Field(typeof(MainWindow), "_autoLeaveIfLost").SetValue(window, true);
        addon.IsVisible = false;
        Tick(); Assert(automation.Leaves == 0, "no leave before elimination overlay");
        addon.IsVisible = true;
        addon.UldManager.LoadedState = AtkLoadState.Unloaded;
        Tick(); Assert(automation.Leaves == 0, "unloaded elimination overlay is ignored");
        addon.UldManager.LoadedState = AtkLoadState.Loaded;
        Tick(); Assert(automation.Leaves == 1, "elimination enqueues leave");
        for (int i = 0; i < 300; ++i) Tick();
        Assert(automation.Leaves == 1, "300 frames do not duplicate queued leave");
        automation.Idle = true;
        Service.Condition[ConditionFlag.BoundByDuty] = false;
        Tick(); Assert(automation.Leaves == 1, "no repeated leave after exiting");
        automation.Idle = true;
        Service.Condition[ConditionFlag.BoundByDuty] = true;
        Tick(); Assert(automation.Leaves == 2, "auto leave still works on next run");
        RaptureAtkUnitManager.AddonAddress = 0;
        automation.Idle = true;
        Tick(); Assert(automation.Leaves == 2, "missing addon is safe");

        var events = (GameEvents)RuntimeHelpers.GetUninitializedObject(typeof(GameEvents));
        var originalCalls = 0;
        ActionEffectHandler.Delegates.Receive original = (uint id, Character* c, Vector3* p, ActionEffectHandler.Header* h, ActionEffectHandler.TargetEffects* e, GameObjectId* t) => ++originalCalls;
        Field(typeof(GameEvents), "_processActionEffectPacketHook").SetValue(events, new Hook<ActionEffectHandler.Delegates.Receive>(original));
        var detour = typeof(GameEvents).GetMethod("ProcessActionEffectPacketDetour", BindingFlags.Instance | BindingFlags.NonPublic)!.CreateDelegate<ActionEffectHandler.Delegates.Receive>(events);
        uint receivedId = 0;
        Vector3 receivedPos = default;
        var callbackCount = 0;
        events.ActionEffectEvent += (id, pos) => { receivedId = id; receivedPos = pos; ++callbackCount; };
        var caster = new Character { GameObject = new() { Position = new(1, 2, 3) } };
        var header = new ActionEffectHandler.Header { ActionId = 34801, ActionType = (byte)ActionType.Action };
        detour(7, &caster, null, &header, null, null);
        Assert(receivedId == 34801 && receivedPos == new Vector3(1, 2, 3), "AOE event receives action ID and caster position");
        header.ActionType = (byte)ActionType.Item;
        detour(7, &caster, null, &header, null, null);
        Assert(originalCalls == 2 && callbackCount == 1, "non-action packets invoke original without AOE event");
        Console.WriteLine($"{checks} behavioral checks passed (game services stubbed).");
    }
}
