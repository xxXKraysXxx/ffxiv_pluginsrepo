using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using System.Reflection;

namespace RSRClassicPanel;

internal sealed class LifestreamRestorer(Func<IEnumerable<IExposedPlugin>> plugins, Configuration config,
    Func<(string Home, string Current)> playerWorlds, Action<Exception, string> logError,
    Action<Version> connected, Func<DateTime> utcNow) : IDisposable
{
    public LifestreamRestorer(IDalamudPluginInterface pluginInterface, IPluginLog log, Configuration config,
        Func<(string Home, string Current)> playerWorlds)
        : this(() => pluginInterface.InstalledPlugins, config, playerWorlds,
            (error, message) => log.Error(error, message),
            version => log.Information("Classic Lifestream overlay connected to {Version}", version), () => DateTime.UtcNow) { }
    private IExposedPlugin? installed;
    private LifestreamBridge? bridge;
    private Assembly? attachedAssembly;
    private object? attachedOwner;
    private LifestreamClassicWindow? replacement;
    private UiReplacementLease? lease;
    private DateTime nextCheck;
    private bool failed;
    private bool reconnect;
    private Exception? drawError;
    public string Status { get; private set; } = "Waiting for Lifestream.";
    public void Retry() { failed = false; reconnect = true; nextCheck = DateTime.MinValue; }

    public void Tick()
    {
        try { TickCore(); }
        catch (Exception error) { Fail(error); }
    }
    private void TickCore()
    {
        // Window-system mutations are made here, outside its Draw enumeration.
        if (drawError is { } error) { drawError = null; Fail(error); }
        if (reconnect) { reconnect = false; Detach(); }
        if (!config.RestoreLifestream)
        {
            Detach(); Status = "Lifestream replacement is off."; return;
        }
        if (installed is { IsLoaded: false }) Detach();
        if (replacement != null && bridge != null) replacement.IsOpen = bridge.Stock.IsOpen;
        if (utcNow() < nextCheck || failed) return;
        nextCheck = utcNow().AddSeconds(1);
        var active = plugins().FirstOrDefault(p => p.InternalName == "Lifestream" && p.IsLoaded);
        if (active == null) { Detach(); Status = "Waiting for Lifestream."; return; }
        try
        {
            var assembly = RsrBridge.AssemblyFor(active);
            var owner = RsrBridge.OwnerFor(active);
            // InstalledPlugins creates new ExposedPlugin wrappers on every enumeration.
            // Compare the live LocalPlugin owner and assembly, never the disposable wrapper.
            if (ReferenceEquals(attachedOwner, owner) && ReferenceEquals(attachedAssembly, assembly)) return;
            Detach();
            if (assembly.GetType("Lifestream.Services.BadgeOverlayManager") == null)
            {
                installed = active; attachedAssembly = assembly; attachedOwner = owner;
                Status = $"Lifestream {active.Version} already uses its classic overlay."; return;
            }
            // MainGui derives from ECommons.SimpleGui.ConfigWindow in 2.6.
            var ecommons = assembly.GetType("Lifestream.GUI.MainGui", true)!.BaseType!.Assembly;
            bridge = new(assembly, ecommons);
            if (!bridge.Ready) { bridge = null; Status = "Waiting for Lifestream to finish initializing."; return; }
            var stock = bridge.Stock;
            var windows = bridge.Windows;
            var badge = bridge.BadgeSubscription();
            replacement = new(bridge, playerWorlds, e => drawError ??= e) { IsOpen = stock.IsOpen };
            var panel = replacement;
            installed = active;
            attachedAssembly = assembly;
            attachedOwner = owner;
            bool IsCurrent() => active.IsLoaded && ReferenceEquals(RsrBridge.AssemblyFor(active), assembly);
            lease = UiReplacementLease.Replace(windows, stock, panel,
                () => badge.Event.RemoveEventHandler(badge.Builder, badge.Draw),
                () => badge.Event.AddEventHandler(badge.Builder, badge.Draw), IsCurrent);
            Status = $"Classic Lifestream overlay active ({active.Version}).";
            connected(active.Version);
        }
        catch (Exception e) { Fail(e); }
    }
    private void Fail(Exception error)
    {
        logError(error, "Lifestream classic UI failed; restoring the stock UI.");
        Detach(); failed = true; Status = $"Lifestream replacement stopped: {error.GetBaseException().Message}";
    }
    private void Detach()
    {
        try { lease?.Dispose(); }
        catch (Exception e) { logError(e, "Error while restoring Lifestream's UI"); }
        lease = null; replacement = null; bridge = null; installed = null; attachedAssembly = null; attachedOwner = null;
    }
    public void Dispose() => Detach();
}
