using System.Reflection;
using Dalamud.Plugin;
using Dalamud.Plugin.Internal.Types.Manifest;

namespace Dalamud.Plugin.Internal.Types
{
    // Same discovery shape as Dalamud's live owner; every exposed wrapper points at this stable object.
    internal sealed class LocalPlugin
    {
        public Assembly Assembly { get; set; } = Assembly.GetExecutingAssembly();
        public bool Loaded = true;
    }
}

namespace RSRClassicPanel.Tests
{
    internal sealed class TestExposedPlugin(Dalamud.Plugin.Internal.Types.LocalPlugin owner) : IExposedPlugin
    {
        private readonly Dalamud.Plugin.Internal.Types.LocalPlugin plugin = owner;
        public string Name => "Lifestream";
        public string InternalName => "Lifestream";
        public bool IsLoaded => plugin.Loaded;
        public bool IsOutdated => false;
        public bool IsTesting => false;
        public bool IsOrphaned => false;
        public bool IsDecommissioned => false;
        public bool IsBanned => false;
        public bool IsDev => false;
        public bool IsThirdParty => true;
        public ILocalPluginManifest Manifest => null!;
        public Version Version => new(2, 6, 0, 7);
        public bool HasMainUi => true;
        public bool HasConfigUi => true;
        public void OpenMainUi() { }
        public void OpenConfigUi() { }
    }
}
