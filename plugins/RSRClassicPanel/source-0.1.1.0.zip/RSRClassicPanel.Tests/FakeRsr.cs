using Dalamud.Interface.Textures.TextureWraps;
using System.ComponentModel;

namespace RotationSolver.Basic.Actions
{
    public interface IAction
    {
        string Name { get; }
        bool EnoughLevel { get; }
        ICooldown Cooldown { get; }
        bool Use();
    }
    public interface ICooldown
    {
        float RecastTimeOneChargeRaw { get; }
        float RecastTimeElapsedRaw { get; }
        bool IsCoolingDown { get; }
        ushort CurrentCharges { get; }
        ushort MaxCharges { get; }
    }
    public interface IBaseAction : IAction
    {
        internal static bool ForceEnable { get; set; }
        bool CanUse(out IAction action, bool usedUp = false, bool skipAoeCheck = false);
    }
    public interface IBaseItem : IAction
    {
        bool CanUse(out IAction item, bool clippingCheck = false);
    }
    internal sealed class FakeAction : IBaseAction
    {
        public string Name => "Test GCD";
        public bool EnoughLevel => true;
        public ICooldown Cooldown => new FakeCooldown();
        public int Uses { get; private set; }
        public bool Usable { get; set; } = true;
        public bool ThrowOnCheck { get; set; }
        public bool ForceObserved { get; private set; }
        public bool FlagsObserved { get; private set; }
        public bool CanUse(out IAction action, bool usedUp = false, bool skipAoeCheck = false)
        {
            ForceObserved = IBaseAction.ForceEnable; FlagsObserved = usedUp && skipAoeCheck;
            action = this;
            if (ThrowOnCheck) throw new InvalidOperationException("Simulated failed action check");
            return Usable;
        }
        public bool Use() { Uses++; return true; }
    }
    internal sealed class FakeItem : IBaseItem
    {
        public string Name => "Test item";
        public bool EnoughLevel => true;
        public ICooldown Cooldown => new FakeCooldown();
        public int Uses { get; private set; }
        public bool ClippingObserved { get; private set; }
        public bool CanUse(out IAction item, bool clippingCheck = false) { item = this; ClippingObserved = clippingCheck; return true; }
        public bool Use() { Uses++; return true; }
    }
    internal readonly struct FakeCooldown : ICooldown
    {
        public float RecastTimeOneChargeRaw => 2.5f;
        public float RecastTimeElapsedRaw => 1;
        public bool IsCoolingDown => true;
        public ushort CurrentCharges => 1;
        public ushort MaxCharges => 2;
    }
}

namespace RotationSolver.Basic.Data
{
    public enum SpecialCommandType { [Description("Area heal")] HealArea, EndSpecial }
    public enum StateCommandType { [Description("Automatic mode")] Auto, Manual, Off }
    public static class IconSet
    {
        public static bool GetTexture(Actions.IAction? action, out IDalamudTextureWrap texture, bool adjust = true) { texture = null!; return false; }
        public static bool GetTexture(uint icon, out IDalamudTextureWrap texture, uint fallback = 0) { texture = null!; return false; }
        public static bool GetTexture(string path, out IDalamudTextureWrap texture, bool loading = false) { texture = null!; return false; }
    }
}

namespace RotationSolver.Basic
{
    internal sealed class ConditionBoolean { public bool Value { get; set; } = true; }
    internal sealed class Configs
    {
        public enum Aoe { Off, Cleave, Full }
        public Aoe AoEType { get; set; } = Aoe.Full;
        public List<string> TargetingTypes { get; set; } = ["LowHP", "HighHP", "Small", "Big"];
        public int TargetingIndex { get; set; }
        public ConditionBoolean AutoBurst { get; set; } = new();
        public ConditionBoolean ShowTooltips { get; set; } = new();
        public ConditionBoolean ShowCooldownsAlways { get; set; } = new();
        public ConditionBoolean UseOriginalCooldown { get; set; } = new();
        public ConditionBoolean OnlyShowWithHostileOrInDuty { get; set; } = new() { Value = false };
        public int Saves { get; private set; }
        public void Save() => Saves++;
    }
    internal static class Service { public static Configs Config { get; set; } = new(); }
    internal static class DataCenter
    {
        public static bool State { get; set; }
        public static bool IsManual { get; set; }
        public static Data.SpecialCommandType SpecialType => Data.SpecialCommandType.HealArea;
        public static double SpecialTimeLeft => 3;
        public static string TargetingType => Service.Config.TargetingTypes.Count == 0 ? "LowHP" : Service.Config.TargetingTypes[Service.Config.TargetingIndex];
        public static object? CurrentRotation { get; set; } = new FakeRotation();
        public static Actions.IAction? CommandNextAction { get; set; }
        public static string CurrentTargetToHostileType => "AllTargetsCanAttack";
        public static string AutoStatus => "None";
        public static bool DrawingActions { get; set; }
        public static float DefaultGCDRemain => 1.5f;
        public static float DefaultGCDTotal => 2.5f;
        public static float DefaultGCDElapsed => 1;
        public static float CalculatedActionAhead => 0.5f;
        public static bool IsPvP { get; set; }
        public static double CommandDuration { get; private set; }
        internal static void AddCommandAction(Actions.IAction action, double time) { CommandNextAction = action; CommandDuration = time; }
    }
    internal sealed class FakeRotation
    {
        public Actions.IAction ActionHealAreaGCD { get; } = new Actions.FakeAction();
    }
}

namespace RotationSolver.Commands
{
    internal static class RSCommands
    {
        public static void SetTargetingIndex(int index) => Basic.Service.Config.TargetingIndex = index;
    }
}

namespace RotationSolver.Updaters
{
    internal static class ActionUpdater
    {
        internal static Basic.Actions.IBaseAction? NextGCDAction { get; set; }
        internal static Basic.Actions.IAction? NextAction { get; set; }
    }
    internal static class MajorUpdater { public static bool IsValid { get; set; } = true; }
}

namespace RotationSolver
{
    internal sealed class FakeWindow { public bool IsOpen { get; set; } }
    internal sealed class RotationSolverPlugin
    {
        internal static FakeWindow _fullControlWindow = new();
        private static bool AnyHostileTargetWithinDistance(float distance) => false;
    }
}
