using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("RSRClassicPanel.Tests")]
