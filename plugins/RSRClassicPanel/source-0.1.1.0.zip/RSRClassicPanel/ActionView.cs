namespace RSRClassicPanel;

internal sealed class ActionView(RsrBridge bridge, object raw)
{
    public object Raw { get; } = raw;
    public string Name => bridge.Access.Read<string>(Raw, "Name");
    public bool EnoughLevel => bridge.Access.Read<bool>(Raw, "EnoughLevel");
    public bool IsBaseAction => bridge.IsBaseAction(Raw);
    public CooldownView Cooldown => new(bridge, bridge.Access.Get(Raw, "Cooldown")!);
    public override string ToString() => Raw.ToString() ?? Name;
    public override bool Equals(object? other) => other is ActionView action && ReferenceEquals(Raw, action.Raw);
    public override int GetHashCode() => System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(Raw);
    public static bool operator ==(ActionView? a, ActionView? b) => Equals(a, b);
    public static bool operator !=(ActionView? a, ActionView? b) => !Equals(a, b);
}

internal sealed class CooldownView(RsrBridge bridge, object raw)
{
    public float RecastTimeOneChargeRaw => bridge.Access.Read<float>(raw, "RecastTimeOneChargeRaw");
    public float RecastTimeElapsedRaw => bridge.Access.Read<float>(raw, "RecastTimeElapsedRaw");
    public bool IsCoolingDown => bridge.Access.Read<bool>(raw, "IsCoolingDown");
    public ushort MaxCharges => bridge.Access.Read<ushort>(raw, "MaxCharges");
    public ushort CurrentCharges => bridge.Access.Read<ushort>(raw, "CurrentCharges");
}
