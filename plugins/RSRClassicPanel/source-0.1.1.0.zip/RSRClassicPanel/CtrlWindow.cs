// Adapted from RotationSolverReborn 7.5.6.13 (LGPL-3.0-or-later).
// Original layout preserved; live data and action access go through RsrBridge.
using Dalamud.Interface.Windowing;

namespace RSRClassicPanel;

internal abstract class CtrlWindow(string name) : Window(name, BaseFlags)
{
	public const ImGuiWindowFlags BaseFlags = ImGuiWindowFlags.NoScrollbar
						| ImGuiWindowFlags.NoNav
						| ImGuiWindowFlags.NoScrollWithMouse;

	public override void PreDraw()
	{
		var config = Service.Config;
		var bgColor = config.IsControlWindowLock
			? config.ControlWindowLockBg
			: config.ControlWindowUnlockBg;
		ImGui.PushStyleColor(ImGuiCol.WindowBg, bgColor);

		Flags = BaseFlags;
		if (config.IsControlWindowLock)
		{
			Flags |= ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove;
		}

		ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0);

		base.PreDraw();
	}

	public override void PostDraw()
	{
		base.PostDraw();
		ImGui.PopStyleColor();
		ImGui.PopStyleVar();
	}
}