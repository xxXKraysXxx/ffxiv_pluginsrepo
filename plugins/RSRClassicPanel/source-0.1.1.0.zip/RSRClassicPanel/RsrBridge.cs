using System.ComponentModel;
using System.Collections;
using System.Reflection;
using Dalamud.Interface.Textures.TextureWraps;

namespace RSRClassicPanel;

internal sealed class RsrBridge(Action<string> sendCommand)
{
    internal readonly ReflectionAccess Access = new();
    private Type? service, data, updater, major, icons, baseAction, itemAction, actionInterface;
    private Type? pluginType, specialEnum, stateEnum;
    private MethodInfo? actionTexture, iconTexture, pathTexture, addCommandAction, canUseAction, canUseItem, useAction;
    private MethodInfo? setTargetingIndex;
    private Func<bool> stillLoaded = () => false;
    public bool Connected { get; private set; }
    public string Status { get; private set; } = "Waiting for Rotation Solver Reborn.";
    public string Version { get; private set; } = "";
    public object Config => Access.Get(service!, "Config") ?? throw new InvalidOperationException("RSR configuration is unavailable.");
    public object? Data(string name) => Access.Get(data!, name);
    public T Data<T>(string name) => Access.Read<T>(data!, name);
    public T ConfigValue<T>(string name) => Access.Read<T>(Config, name);
    public bool ConfigBool(string name) => Access.Read<bool>(Access.Get(Config, name)!, "Value");
    public ActionView? NextGcd => Wrap(Access.Get(updater!, "NextGCDAction"));
    public ActionView? Next => Wrap(Access.Get(updater!, "NextAction"));
    public ActionView? CommandAction => Wrap(Data("CommandNextAction"));
    public bool IsBaseAction(object raw) => baseAction!.IsInstanceOfType(raw);
    public ActionView? Wrap(object? raw) => raw == null ? null : new(this, raw);
    public ActionView? RotationAction(string name) => Data("CurrentRotation") is { } rotation ? Wrap(Access.Get(rotation, name)) : null;

    public static Assembly AssemblyFor(object exposedPlugin)
    {
        // Resolve the live LocalPlugin, rather than guessing among old assemblies left after a reload.
        var ownerField = exposedPlugin.GetType().GetFields(ReflectionAccess.Flags).Single(f =>
            f.FieldType.FullName == "Dalamud.Plugin.Internal.Types.LocalPlugin");
        var owner = ownerField.GetValue(exposedPlugin) ?? throw new InvalidOperationException("RSR has no live plugin owner.");
        return (Assembly)(owner.GetType().GetProperty("Assembly", ReflectionAccess.Flags)?.GetValue(owner)
            ?? throw new InvalidOperationException("RSR's live assembly is unavailable."));
    }

    // Only inspect the live plugin's assemblies. Never load another copy of the combat engine.
    public void Attach(Assembly rsrAssembly, Func<bool> isLoaded)
    {
        Detach();
        var basic = rsrAssembly.GetType("RotationSolver.Updaters.ActionUpdater", true)!
            .GetProperty("NextAction", ReflectionAccess.Flags)!.PropertyType.Assembly;
        AttachTypes(rsrAssembly, basic, isLoaded);
    }

    internal void AttachTypes(Assembly rsr, Assembly basic, Func<bool> isLoaded)
    {
        Type Required(Assembly assembly, string name) => assembly.GetType(name, true)!;
        service = Required(basic, "RotationSolver.Basic.Service");
        data = Required(basic, "RotationSolver.Basic.DataCenter");
        updater = Required(rsr, "RotationSolver.Updaters.ActionUpdater");
        major = Required(rsr, "RotationSolver.Updaters.MajorUpdater");
        pluginType = Required(rsr, "RotationSolver.RotationSolverPlugin");
        icons = Required(basic, "RotationSolver.Basic.Data.IconSet");
        baseAction = Required(basic, "RotationSolver.Basic.Actions.IBaseAction");
        itemAction = Required(basic, "RotationSolver.Basic.Actions.IBaseItem");
        actionInterface = Required(basic, "RotationSolver.Basic.Actions.IAction");
        specialEnum = Required(basic, "RotationSolver.Basic.Data.SpecialCommandType");
        stateEnum = Required(basic, "RotationSolver.Basic.Data.StateCommandType");
        actionTexture = icons.GetMethods().Single(m => m.Name == "GetTexture" && m.GetParameters()[0].ParameterType == actionInterface);
        iconTexture = icons.GetMethods().Single(m => m.Name == "GetTexture" && m.GetParameters()[0].ParameterType == typeof(uint));
        pathTexture = icons.GetMethods().Single(m => m.Name == "GetTexture" && m.GetParameters()[0].ParameterType == typeof(string));
        addCommandAction = Access.Method(data, "AddCommandAction", 2);
        canUseAction = Access.Method(baseAction, "CanUse");
        canUseItem = Access.Method(itemAction, "CanUse");
        useAction = Access.Method(actionInterface, "Use", 0);
        setTargetingIndex = Access.Method(Required(rsr, "RotationSolver.Commands.RSCommands"), "SetTargetingIndex", 1);
        ReflectionAccess.DefaultArguments(canUseAction);
        ReflectionAccess.DefaultArguments(canUseItem);
        foreach (var name in new[] { "State", "IsManual", "SpecialType", "SpecialTimeLeft", "TargetingType",
            "CurrentRotation", "CommandNextAction", "CurrentTargetToHostileType", "AutoStatus", "DrawingActions",
            "DefaultGCDRemain", "DefaultGCDTotal", "DefaultGCDElapsed", "CalculatedActionAhead", "IsPvP" }) Access.Member(data, name);
        Access.Member(baseAction, "ForceEnable");
        Access.Member(major, "IsValid");
        foreach (var name in new[] { "NextGCDAction", "NextAction" }) Access.Member(updater, name);
        foreach (var name in new[] { "AoEType", "AutoBurst", "ShowTooltips", "ShowCooldownsAlways", "UseOriginalCooldown", "TargetingTypes", "TargetingIndex" }) Access.Member(Config.GetType(), name);
        // Validate save and preview contracts before offering any controls.
        Access.Method(Config.GetType(), "Save", 0);
        Access.Member(pluginType, "_fullControlWindow");
        Version = rsr.GetName().Version?.ToString() ?? "unknown";
        stillLoaded = isLoaded;
        Connected = true;
        Status = $"Connected to RSR {Version}";
    }

    public bool IsCurrent => Connected && stillLoaded();
    public bool ValidForPanel => IsCurrent && Access.Read<bool>(major!, "IsValid") && Data("CurrentRotation") != null;
    public bool VisibleByRsrRules()
    {
        if (!ValidForPanel) return false;
        var method = Access.Method(pluginType!, "AnyHostileTargetWithinDistance", 1);
        return !ConfigBool("OnlyShowWithHostileOrInDuty") ||
            Plugin.ConditionBoundByDuty || (bool)method.Invoke(null, [25f])!;
    }

    public void SetDrawing(bool draw)
    {
        if (!IsCurrent) return;
        // RSR's own control panel also owns this flag. Keep its previews when our window closes.
        var stock = Access.Get(pluginType!, "_fullControlWindow");
        var stockOpen = stock != null && Access.Read<bool>(stock, "IsOpen");
        Access.Set(data!, "DrawingActions", draw || stockOpen);
    }

    public void Command(string command)
    {
        if (!IsCurrent || Data<bool>("IsPvP")) return;
        sendCommand(command);
    }

    public void Setting(string name, string value)
    {
        Command($"/rotation Settings {name} {value}");
        Save();
    }

    public void Save()
    {
        if (IsCurrent) Access.Method(Config.GetType(), "Save", 0).Invoke(Config, null);
    }

    public void CycleTargeting()
    {
        if (!IsCurrent || Data<bool>("IsPvP")) return;
        var types = ConfigValue<IList>("TargetingTypes");
        if (types.Count < 2) return;
        var index = ConfigValue<int>("TargetingIndex");
        var normalized = ((index % types.Count) + types.Count) % types.Count;
        // Use RSR's own selector so its state label updates without starting or stopping autorotation.
        setTargetingIndex!.Invoke(null, [(normalized + 1) % types.Count]);
        Save();
    }

    public void ClickAction(ActionView action)
    {
        if (!IsCurrent || Data<bool>("IsPvP")) return;
        if (Data<bool>("State")) { addCommandAction!.Invoke(null, [action.Raw, 5d]); return; }
        var method = IsBaseAction(action.Raw) ? canUseAction : itemAction!.IsInstanceOfType(action.Raw) ? canUseItem : null;
        if (method == null) return;
        var arguments = ReflectionAccess.DefaultArguments(method);
        var parameters = method.GetParameters();
        for (var i = 0; i < parameters.Length; i++)
            if (parameters[i].Name is "usedUp" or "skipAoeCheck" or "clippingCheck") arguments[i] = true;
        var force = IsBaseAction(action.Raw);
        var previous = force && Access.Read<bool>(baseAction!, "ForceEnable");
        bool usable;
        try
        {
            if (force) Access.Set(baseAction!, "ForceEnable", true);
            usable = (bool)method.Invoke(action.Raw, arguments)!;
        }
        finally { if (force) Access.Set(baseAction!, "ForceEnable", previous); }
        if (usable) useAction!.Invoke(action.Raw, null);
    }

    public bool Texture(ActionView? action, out IDalamudTextureWrap texture, bool adjust = true)
    {
        object?[] arguments = [action?.Raw, null, adjust];
        var result = IsCurrent && (bool)actionTexture!.Invoke(null, arguments)!;
        texture = (IDalamudTextureWrap)arguments[1]!;
        return result && texture != null;
    }
    public bool Texture(uint icon, out IDalamudTextureWrap texture)
    {
        object?[] arguments = [icon, null, 0u];
        var result = IsCurrent && (bool)iconTexture!.Invoke(null, arguments)!;
        texture = (IDalamudTextureWrap)arguments[1]!;
        return result && texture != null;
    }
    public bool Texture(string path, out IDalamudTextureWrap texture)
    {
        object?[] arguments = [path, null, false];
        var result = IsCurrent && (bool)pathTexture!.Invoke(null, arguments)!;
        texture = (IDalamudTextureWrap)arguments[1]!;
        return result && texture != null;
    }
    public string Description(string name, bool special)
    {
        var type = special ? specialEnum! : stateEnum!;
        return type.GetField(name)?.GetCustomAttribute<DescriptionAttribute>()?.Description ?? name;
    }
    public string HostileDescription()
    {
        var value = Data("CurrentTargetToHostileType")!;
        return value.GetType().GetField(value.ToString()!)?.GetCustomAttribute<DescriptionAttribute>()?.Description ?? value.ToString()!;
    }

    public void Fail(Exception exception)
    {
        try { SetDrawing(false); } catch { /* incompatible or already unloaded */ }
        Detach();
        var cause = exception is TargetInvocationException { InnerException: { } inner } ? inner : exception;
        Status = $"RSR connection stopped: {cause.Message}";
    }
    public void Detach()
    {
        Connected = false;
        stillLoaded = () => false;
        service = data = updater = major = icons = baseAction = itemAction = actionInterface = pluginType = specialEnum = stateEnum = null;
        actionTexture = iconTexture = pathTexture = addCommandAction = canUseAction = canUseItem = useAction = null;
        setTargetingIndex = null;
        Access.Clear();
        Version = "";
        Status = "Waiting for Rotation Solver Reborn.";
    }
}
