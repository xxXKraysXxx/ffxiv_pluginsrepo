// Adapted from RotationSolverReborn 7.5.6.13 (LGPL-3.0-or-later).
// Original layout preserved; live data and action access go through RsrBridge.
using Dalamud.Interface.Colors;

namespace RSRClassicPanel;

internal static class NextActionWindow
{
	public static void DrawGcdCooldown(float width, bool drawTitle)
	{
		var remain = Plugin.Bridge.Data<float>("DefaultGCDRemain");
		var total = Plugin.Bridge.Data<float>("DefaultGCDTotal");
		var elapsed = Plugin.Bridge.Data<float>("DefaultGCDElapsed");

		if (drawTitle)
		{
			var str = $"{remain:F2}s / {total:F2}s";
			ImGui.SetCursorPosX(ImGui.GetCursorPosX() + (width / 2) - (ImGui.CalcTextSize(str).X / 2));
			ImGui.Text(str);
		}

		var cursor = ImGui.GetCursorPos() + ImGui.GetWindowPos();
		var height = Service.Config.ControlProgressHeight;

		// Total is 0 before the first GCD is used; avoid feeding NaN to the progress bar.
		ImGui.ProgressBar(total > 0 ? elapsed / total : 0f, new Vector2(width, height), string.Empty);

		if (remain > 0 && total > 0)
		{
			var value = total - Plugin.Bridge.Data<float>("CalculatedActionAhead");

			var playerObject = Plugin.Objects.LocalPlayer;
			if (playerObject != null && value > playerObject.TotalCastTime)
			{
				var pt = cursor + (new Vector2(width, 0) * value / total);

				ImGui.GetWindowDrawList().AddLine(pt, pt + new Vector2(0, height),
					ImGui.ColorConvertFloat4ToU32(ImGuiColors.DalamudRed), 2);
			}
		}
	}
}