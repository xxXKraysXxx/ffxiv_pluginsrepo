// Adapted from RotationSolverReborn 7.5.6.13 (LGPL-3.0-or-later).
// Original layout preserved; live data and action access go through RsrBridge.
using Dalamud.Interface.Textures.TextureWraps;

namespace RSRClassicPanel;

internal static class ImGuiHelper
{
	public static bool SelectableCombo(string popUp, string[] items, ref int index, ImFontPtr? font = null, Vector4? color = null)
	{
		var count = items.Length;
		if (count == 0)
		{
			return false;
		}

		var originIndex = index;
		index = Math.Max(0, index) % count;
		var name = items[index] + "##" + popUp;

		var result = originIndex != index;

		if (SelectableButton(name, font, color))
		{
			if (count < 3)
			{
				index = (index + 1) % count;
				result = true;
			}
			else
			{
				if (!ImGui.IsPopupOpen(popUp))
				{
					ImGui.OpenPopup(popUp);
				}
			}
		}

		if (ImGui.IsItemHovered())
		{
			ImGui.SetMouseCursor(ImGuiMouseCursor.Hand);
		}

		ImGui.SetNextWindowSizeConstraints(Vector2.Zero, Vector2.One * 500);
		if (ImGui.BeginPopup(popUp))
		{
			for (var i = 0; i < count; i++)
			{
				if (ImGui.Selectable(items[i]))
				{
					index = i;
					result = true;
				}
			}
			ImGui.EndPopup();
		}

		return result;
	}

	public static unsafe bool SelectableButton(string name, ImFontPtr? font = null, Vector4? color = null)
	{
		// Called for many buttons every frame, so push/pop directly instead of allocating disposables.
		if (font != null)
		{
			ImGui.PushFont(font.Value);
		}

		var colorCount = 3;
		if (color != null)
		{
			ImGui.PushStyleColor(ImGuiCol.Text, color.Value);
			colorCount++;
		}

		ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImGui.ColorConvertFloat4ToU32(*ImGui.GetStyleColorVec4(ImGuiCol.HeaderActive)));
		ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImGui.ColorConvertFloat4ToU32(*ImGui.GetStyleColorVec4(ImGuiCol.HeaderHovered)));
		ImGui.PushStyleColor(ImGuiCol.Button, 0);
		var result = ImGui.Button(name);
		ImGui.PopStyleColor(colorCount);

		if (font != null)
		{
			ImGui.PopFont();
		}

		return result;
	}


	internal static unsafe bool NoPaddingNoColorImageButton(IDalamudTextureWrap handle, Vector2 size, string id = "")
	{
		if (handle == null)
		{
			return false;
		}

		return NoPaddingNoColorImageButton(handle, size, Vector2.Zero, Vector2.One, id);
	}

	internal static bool NoPaddingNoColorImageButton(IDalamudTextureWrap handle, Vector2 size, Vector2 uv0, Vector2 uv1, string id = "")
	{
		if (handle == null)
		{
			return false;
		}

		const int StyleColorCount = 3;

		ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0);
		ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0);
		ImGui.PushStyleColor(ImGuiCol.Button, 0);
		var buttonClicked = NoPaddingImageButton(handle, size, uv0, uv1, id);
		ImGui.PopStyleColor(StyleColorCount);

		return buttonClicked;
	}

	internal static bool NoPaddingImageButton(IDalamudTextureWrap handle, Vector2 size, Vector2 uv0, Vector2 uv1, string id = "")
	{
		if (handle == null || id == null)
		{
			return false;
		}

		var style = ImGui.GetStyle();
		var originalPadding = style.FramePadding;
		style.FramePadding = Vector2.Zero;

		//https://xkcd.com/2347/
		ImGui.PushID(id + "literally anything");
		//https://xkcd.com/2347/

		var buttonClicked = false;
		var drawn = false;
		try
		{
			if (!handle.Handle.IsNull)
			{
				buttonClicked = ImGui.ImageButton(handle.Handle, size, uv0, uv1);
				drawn = true;
			}
		}
		catch (ObjectDisposedException)
		{
			buttonClicked = false;
			drawn = false;
		}
		catch
		{
			buttonClicked = false;
			drawn = false;
		}
		finally
		{
			ImGui.PopID();
			style.FramePadding = originalPadding;
		}

		if (drawn && ImGui.IsItemHovered())
		{
			ImGui.SetMouseCursor(ImGuiMouseCursor.Hand);
		}

		return buttonClicked;
	}


	internal static readonly uint ProgressCol = ImGui.ColorConvertFloat4ToU32(new Vector4(0.6f, 0.6f, 0.6f, 0.7f));
	internal static readonly uint Black = ImGui.ColorConvertFloat4ToU32(new Vector4(0, 0, 0, 1));
	internal static readonly uint White = ImGui.ColorConvertFloat4ToU32(new Vector4(1, 1, 1, 1));

	internal static void TextShade(Vector2 pos, string text, float width = 1.5f)
	{
		var drawList = ImGui.GetWindowDrawList();
		drawList.AddText(pos + new Vector2(0, -width), Black, text);
		drawList.AddText(pos + new Vector2(0, width), Black, text);
		drawList.AddText(pos + new Vector2(-width, 0), Black, text);
		drawList.AddText(pos + new Vector2(width, 0), Black, text);
		drawList.AddText(pos, White, text);
	}

	// Resolve overlay cover textures per draw to avoid using disposed wraps.
	// Do not cache IDalamudTextureWrap instances long-term; the provider may dispose them.

	internal static void DrawActionOverlay(Vector2 cursor, float width, float percent)
	{
		var pixPerUnit = width / 82f;

		_ = IconSet.GetTexture("ui/uld/icona_frame_hr1.tex", out var coverFrame);
		_ = IconSet.GetTexture("ui/uld/icona_recast_hr1.tex", out var coverRecast);
		_ = IconSet.GetTexture("ui/uld/icona_recast2_hr1.tex", out var coverRecast2);

		try
		{
			if (percent < 0f)
			{
				if (coverFrame?.Handle != null)
				{
					ImGui.SetCursorPos(cursor - new Vector2(pixPerUnit * 3, pixPerUnit * 4));
					Vector2 start = new(4f / coverFrame.Width, 96f * 2 / coverFrame.Height);
					ImGui.Image(coverFrame.Handle, new Vector2(pixPerUnit * 88, pixPerUnit * 94),
						start, start + new Vector2(88f / coverFrame.Width, 94f / coverFrame.Height));
				}
				return;
			}

			if (percent < 1f)
			{
				if (coverRecast?.Handle != null)
				{
					ImGui.SetCursorPos(cursor - new Vector2(pixPerUnit * 3, 0));
					var P = (int)(percent * 81f);
					Vector2 step = new(88f / coverRecast.Width, 96f / coverRecast.Height);
					Vector2 start = new((P % 9) * step.X, (P / 9) * step.Y);
					ImGui.Image(coverRecast.Handle, new Vector2(pixPerUnit * 88, pixPerUnit * 94),
						start, start + new Vector2(88f / coverRecast.Width, 94f / coverRecast.Height));
				}
			}
			else
			{
				if (coverFrame?.Handle != null)
				{
					ImGui.SetCursorPos(cursor - new Vector2(pixPerUnit * 3, pixPerUnit * 4));
					ImGui.Image(coverFrame.Handle, new Vector2(pixPerUnit * 88, pixPerUnit * 94),
						new Vector2(4f / coverFrame.Width, 0f / coverFrame.Height),
						new Vector2(92f / coverFrame.Width, 94f / coverFrame.Height));
				}
			}

			if (percent > 1f && coverRecast2?.Handle != null)
			{
				ImGui.SetCursorPos(cursor - new Vector2(pixPerUnit * 3, 0));
				var P = (int)(percent % 1f * 81f);
				Vector2 step = new(88f / coverRecast2.Width, 96f / coverRecast2.Height);
				Vector2 start = new(((P % 9) + 9) * step.X, (P / 9) * step.Y);
				ImGui.Image(coverRecast2.Handle, new Vector2(pixPerUnit * 88, pixPerUnit * 94),
					start, start + new Vector2(88f / coverRecast2.Width, 94f / coverRecast2.Height));
			}
		}
		catch (ObjectDisposedException)
		{
			// A texture was disposed between fetch and draw; skip this frame to avoid propagating.
		}
		catch
		{
			// Defensive: avoid bubbling up draw exceptions from overlay.
		}
	}

}
