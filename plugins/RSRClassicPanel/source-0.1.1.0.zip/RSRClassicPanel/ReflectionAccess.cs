using System.Reflection;

namespace RSRClassicPanel;

// No references to RSR DLLs: never load a second copy of RSR or its combat engine.
internal sealed class ReflectionAccess
{
    internal const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic |
        BindingFlags.Instance | BindingFlags.Static;
    private readonly Dictionary<(Type, string), MemberInfo> members = [];

    public MemberInfo Member(Type type, string name)
    {
        if (members.TryGetValue((type, name), out var cached)) return cached;
        for (var current = type; current != null; current = current.BaseType)
        {
            MemberInfo? found = current.GetProperty(name, Flags | BindingFlags.DeclaredOnly);
            found ??= current.GetField(name, Flags | BindingFlags.DeclaredOnly);
            if (found != null) return members[(type, name)] = found;
        }
        foreach (var contract in type.GetInterfaces())
            if (contract.GetProperty(name, Flags) is { } property)
                return members[(type, name)] = property;
        throw new MissingMemberException(type.FullName, name);
    }

    public object? Get(object target, string name)
    {
        var type = target as Type ?? target.GetType();
        var instance = target is Type ? null : target;
        return Member(type, name) switch
        {
            PropertyInfo property => property.GetValue(instance),
            FieldInfo field => field.GetValue(instance),
            _ => throw new MissingMemberException(type.FullName, name),
        };
    }

    public T Read<T>(object target, string name) => (T)(Get(target, name)
        ?? throw new InvalidOperationException($"{name} unexpectedly returned null."));

    public void Set(object target, string name, object? value)
    {
        var type = target as Type ?? target.GetType();
        var instance = target is Type ? null : target;
        switch (Member(type, name))
        {
            case PropertyInfo property: property.SetValue(instance, value); break;
            case FieldInfo field: field.SetValue(instance, value); break;
        }
    }

    public MethodInfo Method(Type type, string name, int? parameterCount = null) =>
        type.GetMethods(Flags).Single(m => m.Name == name &&
            (parameterCount == null || m.GetParameters().Length == parameterCount));

    public static object?[] DefaultArguments(MethodInfo method) => method.GetParameters()
        .Select(p => p.IsOut ? null : p.HasDefaultValue ? p.DefaultValue :
            throw new MissingMethodException($"Required parameter {method.Name}.{p.Name} has changed.")).ToArray();

    public void Clear() => members.Clear();
}
