param([string]$DalamudLibPath)
$ErrorActionPreference = 'Stop'

if (-not $DalamudLibPath) {
    $taskHooksPath = Join-Path $env:APPDATA 'XIVLauncher\addon\Hooks'
    $taskDalamudDirectory = Get-ChildItem -LiteralPath $taskHooksPath -Directory |
        Where-Object { $_.Name -match '^15\.\d+\.\d+\.\d+$' } |
        Sort-Object { [version]$_.Name } -Descending |
        Select-Object -First 1
    if (-not $taskDalamudDirectory) { throw 'Dalamud API 15 libraries were not found. Supply -DalamudLibPath.' }
    $DalamudLibPath = $taskDalamudDirectory.FullName
}
if (-not (Test-Path -LiteralPath (Join-Path $DalamudLibPath 'Dalamud.dll'))) {
    throw 'DalamudLibPath must contain Dalamud.dll.'
}
& dotnet build (Join-Path $PSScriptRoot 'RSRClassicPanel.csproj') -c Release "-p:DalamudLibPath=$DalamudLibPath" --nologo
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
Write-Output (Join-Path $PSScriptRoot 'bin\Release\net10.0-windows\RSRClassicPanel.dll')
