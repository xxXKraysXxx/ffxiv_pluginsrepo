using System.Reflection;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace RSRClassicPanel;

public sealed class Plugin : IDalamudPlugin
{
    private readonly IDalamudPluginInterface pluginInterface;
    private readonly ICommandManager commands;
    private readonly IPluginLog log;
    private readonly ICondition condition;
    private readonly WindowSystem windows = new("RSRClassicPanel");
    private readonly Configuration configuration;
    private readonly ControlWindow panel;
    private readonly SettingsWindow settings;
    private IExposedPlugin? attachedPlugin;
    private DateTime nextConnectionCheck;
    private bool connectionFailed;
    private bool disposed;
    private static Plugin? current;
    internal static RsrBridge Bridge { get; private set; } = null!;
    internal static IObjectTable Objects { get; private set; } = null!;
    internal static bool ConditionBoundByDuty { get; private set; }

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commands,
        IPluginLog log, IObjectTable objects, ICondition condition)
    {
        this.pluginInterface = pluginInterface;
        current = this;
        this.commands = commands;
        this.log = log;
        this.condition = condition;
        Objects = objects;
        configuration = pluginInterface.GetPluginConfig() as Configuration ?? new();
        configuration.Normalize();
        Bridge = new(command => commands.ProcessCommand(command));
        Service.Config = new(Bridge, configuration, Save);
        panel = new();
        settings = new(configuration, Save, Retry, () => Bridge.Status);
        windows.AddWindow(panel);
        windows.AddWindow(settings);
        commands.AddHandler("/rsrclassic", new CommandInfo(OnCommand)
        {
            HelpMessage = "Toggle the old RSR control panel. /rsrclassic config: panel settings; /rsrclassic retry: reconnect.",
        });
        pluginInterface.UiBuilder.Draw += Draw;
        pluginInterface.UiBuilder.OpenMainUi += Toggle;
        pluginInterface.UiBuilder.OpenConfigUi += OpenSettings;
        pluginInterface.ActivePluginsChanged += ActivePluginsChanged;
    }

    private void Save() => pluginInterface.SavePluginConfig(configuration);
    private void Toggle() { configuration.ShowPanel = !configuration.ShowPanel; Save(); }
    private void OpenSettings() => settings.IsOpen = true;
    private void Retry() { connectionFailed = false; nextConnectionCheck = DateTime.MinValue; }
    private void OnCommand(string command, string arguments)
    {
        switch (arguments.Trim().ToLowerInvariant())
        {
            case "config": OpenSettings(); break;
            case "retry": Retry(); break;
            case "show": configuration.ShowPanel = true; Save(); break;
            case "hide": configuration.ShowPanel = false; Save(); break;
            default: Toggle(); break;
        }
    }
    private void ActivePluginsChanged(IActivePluginsChangedEventArgs args)
    {
        // Do all reflection and preview changes on the UI thread, after the loader's event finishes.
        Retry();
    }

    private void Connect()
    {
        if (DateTime.UtcNow < nextConnectionCheck) return;
        nextConnectionCheck = DateTime.UtcNow.AddSeconds(1);
        var installed = pluginInterface.InstalledPlugins.FirstOrDefault(p => p.InternalName == "RotationSolver" && p.IsLoaded);
        if (installed == null)
        {
            Bridge.Detach(); attachedPlugin = null; connectionFailed = false; return;
        }
        if (Bridge.IsCurrent || connectionFailed) return;
        try
        {
            var assembly = RsrBridge.AssemblyFor(installed);
            Bridge.Attach(assembly, () => !disposed && installed.IsLoaded && ReferenceEquals(attachedPlugin, installed));
            attachedPlugin = installed;
            log.Information("RSR Classic Panel connected to RSR {Version}", Bridge.Version);
        }
        catch (Exception exception) { Fail(exception); }
    }

    private void Fail(Exception exception)
    {
        log.Error(exception, "RSR Classic Panel connection failed; use /rsrclassic retry after updating RSR.");
        Bridge.Fail(exception);
        attachedPlugin = null;
        connectionFailed = true;
    }

    internal static void ReportFailure(Exception exception) => current?.Fail(exception);

    private void Draw()
    {
        ConditionBoundByDuty = condition[ConditionFlag.BoundByDuty];
        if (Bridge.Connected && !Bridge.IsCurrent) { Bridge.Detach(); attachedPlugin = null; }
        Connect();
        try
        {
            var visible = configuration.ShowPanel;
            if (Bridge.IsCurrent)
            {
                visible &= configuration.FollowRsrVisibility ? Bridge.VisibleByRsrRules() : Bridge.ValidForPanel;
                Bridge.SetDrawing(visible);
            }
            panel.IsOpen = visible;
            var before = panel.IsOpen;
            windows.Draw();
            if (before && !panel.IsOpen) { configuration.ShowPanel = false; Save(); }
        }
        catch (Exception exception) { Fail(exception); }
    }

    public void Dispose()
    {
        try { Bridge.SetDrawing(false); } catch { /* RSR may have unloaded first */ }
        disposed = true;
        pluginInterface.UiBuilder.Draw -= Draw;
        pluginInterface.UiBuilder.OpenMainUi -= Toggle;
        pluginInterface.UiBuilder.OpenConfigUi -= OpenSettings;
        pluginInterface.ActivePluginsChanged -= ActivePluginsChanged;
        commands.RemoveHandler("/rsrclassic");
        windows.RemoveAllWindows();
        Bridge.Detach();
        current = null;
        Save();
    }
}
