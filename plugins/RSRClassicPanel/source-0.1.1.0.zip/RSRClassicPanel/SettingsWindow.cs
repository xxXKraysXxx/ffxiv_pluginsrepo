using Dalamud.Interface.Windowing;

namespace RSRClassicPanel;

internal sealed class SettingsWindow(Configuration config, Action save, Action retry, Func<string> status)
    : Window("RSR Classic Panel Settings", ImGuiWindowFlags.AlwaysAutoResize)
{
    public override void Draw()
    {
        ImGui.TextUnformatted(status());
        if (ImGui.Button("Reconnect to RSR")) retry();
        ImGui.Separator();
        var show = config.ShowPanel;
        if (ImGui.Checkbox("Show classic panel", ref show)) { config.ShowPanel = show; save(); }
        var locked = config.Locked;
        if (ImGui.Checkbox("Lock panel position and size", ref locked)) { config.Locked = locked; save(); }
        var follow = config.FollowRsrVisibility;
        if (ImGui.Checkbox("Follow RSR's enemies / duty visibility setting", ref follow)) { config.FollowRsrVisibility = follow; save(); }
        ImGui.SetNextItemWidth(220);
        var gcd = config.GcdIconSize;
        if (ImGui.SliderFloat("GCD icon size", ref gcd, 8, 80)) { config.GcdIconSize = gcd; save(); }
        ImGui.SetNextItemWidth(220);
        var ability = config.AbilityIconSize;
        if (ImGui.SliderFloat("oGCD icon size", ref ability, 8, 80)) { config.AbilityIconSize = ability; save(); }
        ImGui.SetNextItemWidth(220);
        var next = config.NextSizeRatio;
        if (ImGui.SliderFloat("Next action size ratio", ref next, 0.5f, 3)) { config.NextSizeRatio = next; save(); }
        ImGui.SetNextItemWidth(220);
        var height = config.ProgressHeight;
        if (ImGui.SliderFloat("GCD progress height", ref height, 2, 30)) { config.ProgressHeight = height; save(); }
        var lockedBg = config.LockedBackground;
        if (ImGui.ColorEdit4("Locked background", ref lockedBg)) { config.LockedBackground = lockedBg; save(); }
        var unlockedBg = config.UnlockedBackground;
        if (ImGui.ColorEdit4("Unlocked background", ref unlockedBg)) { config.UnlockedBackground = unlockedBg; save(); }
        if (ImGui.Button("Reset panel appearance"))
        {
            var defaults = new Configuration();
            config.GcdIconSize = defaults.GcdIconSize; config.AbilityIconSize = defaults.AbilityIconSize;
            config.NextSizeRatio = defaults.NextSizeRatio; config.ProgressHeight = defaults.ProgressHeight;
            config.LockedBackground = defaults.LockedBackground; config.UnlockedBackground = defaults.UnlockedBackground;
            save();
        }
        ImGui.Separator();
        ImGui.TextUnformatted("Disable RSR's Show Control Window setting to avoid duplicate panels.");
        ImGui.TextUnformatted("RSR keeps its normal updates. Only this panel is replaced.");
    }
}
