using Dalamud.Configuration;

namespace RSRClassicPanel;

public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    public bool ShowPanel { get; set; } = true;
    public bool Locked { get; set; }
    public float GcdIconSize { get; set; } = 40f;
    public float AbilityIconSize { get; set; } = 30f;
    public float NextSizeRatio { get; set; } = 1.5f;
    public float ProgressHeight { get; set; } = 8f;
    public Vector4 LockedBackground { get; set; } = new(0, 0, 0, 0.55f);
    public Vector4 UnlockedBackground { get; set; } = new(0, 0, 0, 0.75f);
    public bool FollowRsrVisibility { get; set; } = true;

    public void Normalize()
    {
        GcdIconSize = Clamp(GcdIconSize, 8, 80, 40);
        AbilityIconSize = Clamp(AbilityIconSize, 8, 80, 30);
        NextSizeRatio = Clamp(NextSizeRatio, 0.5f, 3, 1.5f);
        ProgressHeight = Clamp(ProgressHeight, 2, 30, 8);
    }

    private static float Clamp(float value, float min, float max, float fallback) =>
        float.IsFinite(value) ? Math.Clamp(value, min, max) : fallback;
}
