namespace RSRClassicPanel;

// These facades preserve the original renderer's layout code while routing it to live RSR state.
internal static class Service
{
    public static ConfigFacade Config { get; set; } = null!;
}

internal sealed class BoolSetting(Func<bool> get, Action<bool> set)
{
    public bool Value { get => get(); set => set(value); }
    public static implicit operator bool(BoolSetting value) => value.Value;
}

internal static class ConfigTypes
{
    internal enum AoEType { Off, Cleave, Full }
}

internal sealed class ConfigFacade(RsrBridge bridge, Configuration local, Action saveLocal)
{
    public float ControlWindowGCDSize => local.GcdIconSize;
    public float ControlWindow0GCDSize => local.AbilityIconSize;
    public float ControlWindowNextSizeRatio => local.NextSizeRatio;
    public float ControlProgressHeight => local.ProgressHeight;
    public Vector4 ControlWindowLockBg => local.LockedBackground;
    public Vector4 ControlWindowUnlockBg => local.UnlockedBackground;
    public bool ShowTooltips => bridge.ConfigBool("ShowTooltips");
    public bool ShowCooldownsAlways => bridge.ConfigBool("ShowCooldownsAlways");
    public bool UseOriginalCooldown => bridge.ConfigBool("UseOriginalCooldown");
    public BoolSetting IsControlWindowLock => new(() => local.Locked, value => { local.Locked = value; saveLocal(); });
    public BoolSetting AutoBurst => new(() => bridge.ConfigBool("AutoBurst"), value => bridge.Setting("AutoBurst", value.ToString()));
    public ConfigTypes.AoEType AoEType
    {
        get => Enum.Parse<ConfigTypes.AoEType>(bridge.ConfigValue<object>("AoEType").ToString()!);
        set => bridge.Setting("AoEType", value.ToString());
    }
}

internal sealed class RotationView(RsrBridge bridge)
{
    public ActionView? ActionHealAreaGCD => bridge.RotationAction(nameof(ActionHealAreaGCD));
    public ActionView? ActionHealAreaAbility => bridge.RotationAction(nameof(ActionHealAreaAbility));
    public ActionView? ActionHealSingleGCD => bridge.RotationAction(nameof(ActionHealSingleGCD));
    public ActionView? ActionHealSingleAbility => bridge.RotationAction(nameof(ActionHealSingleAbility));
    public ActionView? ActionDefenseAreaGCD => bridge.RotationAction(nameof(ActionDefenseAreaGCD));
    public ActionView? ActionDefenseAreaAbility => bridge.RotationAction(nameof(ActionDefenseAreaAbility));
    public ActionView? ActionDefenseSingleGCD => bridge.RotationAction(nameof(ActionDefenseSingleGCD));
    public ActionView? ActionDefenseSingleAbility => bridge.RotationAction(nameof(ActionDefenseSingleAbility));
    public ActionView? ActionMoveForwardGCD => bridge.RotationAction(nameof(ActionMoveForwardGCD));
    public ActionView? ActionMoveForwardAbility => bridge.RotationAction(nameof(ActionMoveForwardAbility));
    public ActionView? ActionMoveBackAbility => bridge.RotationAction(nameof(ActionMoveBackAbility));
    public ActionView? ActionDispelStancePositionalGCD => bridge.RotationAction(nameof(ActionDispelStancePositionalGCD));
    public ActionView? ActionDispelStancePositionalAbility => bridge.RotationAction(nameof(ActionDispelStancePositionalAbility));
    public ActionView? ActionRaiseShirkGCD => bridge.RotationAction(nameof(ActionRaiseShirkGCD));
    public ActionView? ActionRaiseShirkAbility => bridge.RotationAction(nameof(ActionRaiseShirkAbility));
    public ActionView? ActionAntiKnockbackAbility => bridge.RotationAction(nameof(ActionAntiKnockbackAbility));
    public ActionView? ActionSpeedAbility => bridge.RotationAction(nameof(ActionSpeedAbility));
}

internal static class DataCenter
{
    private static RsrBridge Bridge => Plugin.Bridge;
    public static bool DrawingActions { set => Bridge.SetDrawing(value); }
    public static bool State => Bridge.Data<bool>(nameof(State));
    public static bool IsManual => Bridge.Data<bool>(nameof(IsManual));
    public static object TargetingType => Bridge.Data(nameof(TargetingType))!;
    public static object AutoStatus => Bridge.Data(nameof(AutoStatus))!;
    public static double SpecialTimeLeft => Bridge.Data<double>(nameof(SpecialTimeLeft));
    public static SpecialCommandType SpecialType => Enum.TryParse<SpecialCommandType>(Bridge.Data(nameof(SpecialType))!.ToString(), out var value) ? value : SpecialCommandType.EndSpecial;
    public static RotationView? CurrentRotation => Bridge.Data(nameof(CurrentRotation)) == null ? null : new(Bridge);
    public static ActionView? CommandNextAction => Bridge.CommandAction;
    public static DescribedValue CurrentTargetToHostileType => new(Bridge.HostileDescription());
}

internal sealed record DescribedValue(string Description)
{
    public string GetDescription() => Description;
}

internal static class ActionUpdater
{
    public static ActionView? NextGCDAction => Plugin.Bridge.NextGcd;
    public static ActionView? NextAction => Plugin.Bridge.Next;
}

internal enum StateCommandType { Auto, Manual, Off }
internal enum SpecialCommandType
{
    EndSpecial, HealArea, HealSingle, DefenseArea, DefenseSingle, DispelStancePositional,
    RaiseShirk, MoveForward, MoveBack, AntiKnockback, Burst, Speed, NoCasting,
}
internal static class CommandExtensions
{
    public static string GetDescription(this StateCommandType command) => Plugin.Bridge.Description(command.ToString(), false);
    public static string GetDescription(this SpecialCommandType command) => Plugin.Bridge.Description(command.ToString(), true);
    public static string GetCommandStr(this Enum command) => $"/rotation {command}";
}

internal static class IconSet
{
    public static bool GetTexture(uint icon, out Dalamud.Interface.Textures.TextureWraps.IDalamudTextureWrap texture) => Plugin.Bridge.Texture(icon, out texture);
    public static bool GetTexture(string path, out Dalamud.Interface.Textures.TextureWraps.IDalamudTextureWrap texture) => Plugin.Bridge.Texture(path, out texture);
    public static bool GetTexture(this ActionView? action, out Dalamud.Interface.Textures.TextureWraps.IDalamudTextureWrap texture, bool isAdjust = true) => Plugin.Bridge.Texture(action, out texture, isAdjust);
}
