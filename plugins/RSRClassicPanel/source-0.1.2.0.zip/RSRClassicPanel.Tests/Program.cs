using System.Reflection;
using RSRClassicPanel;
using RotationSolver.Basic;
using RotationSolver.Basic.Actions;
using RsrData = RotationSolver.Basic.DataCenter;
using Service = RotationSolver.Basic.Service;

var checks = 0;
void Check(bool condition, string name) { if (!condition) throw new Exception(name); checks++; }
var commands = new List<string>();
var loaded = true;
var bridge = new RsrBridge(commands.Add);
bridge.AttachTypes(Assembly.GetExecutingAssembly(), Assembly.GetExecutingAssembly(), () => loaded);
Check(bridge.IsCurrent, "Connects to fake live RSR");
Check(bridge.ValidForPanel && bridge.VisibleByRsrRules(), "Respects current rotation and normal visibility");
Service.Config.OnlyShowWithHostileOrInDuty.Value = true;
Check(!bridge.VisibleByRsrRules(), "Hides outside duty without enemies");
Service.Config.OnlyShowWithHostileOrInDuty.Value = false;
var action = new FakeAction();
var view = bridge.Wrap(action)!;
Check(view.Name == "Test GCD" && view.Cooldown.MaxCharges == 2, "Reads names and boxed cooldown structs");
Check(view == bridge.Wrap(action), "Action wrappers preserve identity");
bridge.ClickAction(view);
Check(action.Uses == 1 && action.ForceObserved && action.FlagsObserved, "Off-mode action click matches original CanUse options");
Check(!IBaseAction.ForceEnable, "ForceEnable restored after click");
IBaseAction.ForceEnable = true;
bridge.ClickAction(view);
Check(IBaseAction.ForceEnable, "Preserves a pre-existing ForceEnable value");
IBaseAction.ForceEnable = false;
action.ThrowOnCheck = true;
try { bridge.ClickAction(view); throw new Exception("Expected failed check"); }
catch (TargetInvocationException) { Check(!IBaseAction.ForceEnable, "Restores ForceEnable when CanUse throws"); }
action.ThrowOnCheck = false;
action.Usable = false;
var uses = action.Uses;
bridge.ClickAction(view);
Check(action.Uses == uses, "Does not use unavailable actions");
RsrData.State = true;
bridge.ClickAction(view);
Check(ReferenceEquals(RsrData.CommandNextAction, action) && RsrData.CommandDuration == 5 && action.Uses == uses,
    "Active-mode click queues a five-second command without executing directly");
Check(RsrData.CommandTarget == null, "New queue signature preserves RSR's default target selection");
var access = new ReflectionAccess();
var oldQueueMethod = access.MethodWithOptionalTail(typeof(OldQueue), "AddCommandAction", typeof(IAction), typeof(double));
oldQueueMethod.Invoke(null, ReflectionAccess.ArgumentsWithOptionalTail(oldQueueMethod, action, 5d));
Check(ReferenceEquals(OldQueue.Action, action) && OldQueue.Duration == 5, "Legacy two-argument queue remains compatible");
try
{
    access.MethodWithOptionalTail(typeof(IncompatibleQueue), "AddCommandAction", typeof(IAction), typeof(double));
    throw new Exception("Expected rejection of a new required argument");
}
catch (InvalidOperationException) { Check(true, "Rejects an unknown required queue argument"); }
RsrData.State = false;
var item = new FakeItem();
bridge.ClickAction(bridge.Wrap(item)!);
Check(item.Uses == 1 && item.ClippingObserved, "Off-mode item click checks clipping and uses the item");
bridge.Setting("AoEType", "Off");
Check(commands.Last() == "/rotation Settings AoEType Off" && Service.Config.Saves == 1, "Changes settings through the RSR command and saves");
RsrData.IsPvP = true;
var commandCount = commands.Count;
bridge.Command("/rotation Auto");
bridge.ClickAction(view);
Check(commands.Count == commandCount && action.Uses == uses, "Blocks action commands in PvP");
RsrData.IsPvP = false;
bridge.SetDrawing(true);
Check(RsrData.DrawingActions, "Requests live preview icons");
RotationSolver.RotationSolverPlugin._fullControlWindow.IsOpen = true;
bridge.SetDrawing(false);
Check(RsrData.DrawingActions, "Keeps previews for an open stock panel");
RotationSolver.RotationSolverPlugin._fullControlWindow.IsOpen = false;
bridge.SetDrawing(false);
Check(!RsrData.DrawingActions, "Releases previews when both panels close");
Check(bridge.Description("Auto", false) == "Automatic mode" && bridge.Description("HealArea", true) == "Area heal", "Reads RSR's own tooltip descriptions");
Service.Config.TargetingIndex = 0;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1 && bridge.Data("TargetingType")!.ToString() == "HighHP" && !RsrData.State,
    "Targeting cycle follows the configured list without enabling autorotation");
Service.Config.TargetingIndex = 3;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 0, "Targeting cycle wraps to the first mode");
Service.Config.TargetingTypes = ["Big", "Small"];
RsrData.State = RsrData.IsManual = true;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1 && RsrData.State && RsrData.IsManual, "Targeting cycle respects custom order and preserves Manual mode");
RsrData.State = RsrData.IsManual = false;
RsrData.IsPvP = true;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Targeting cycle does not change PvP settings");
RsrData.IsPvP = false;
Service.Config.TargetingTypes.Clear();
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Empty targeting list is a safe no-op");
loaded = false;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Targeting cycle ignores an unloaded RSR");
bridge.Command("/rotation Auto");
Check(!bridge.IsCurrent && commands.Count == commandCount, "Ignores commands after RSR unloads");
bridge.Detach();
Check(!bridge.Connected && !bridge.IsCurrent, "Detach clears connection");
loaded = true;
bridge.AttachTypes(Assembly.GetExecutingAssembly(), Assembly.GetExecutingAssembly(), () => loaded);
Check(bridge.IsCurrent, "Reconnects after reload");
bridge.Fail(new InvalidOperationException("test disconnect"));
Check(!bridge.Connected && bridge.Status.Contains("test disconnect"), "Reports bridge failure and disables commands");
var config = new Configuration { GcdIconSize = float.NaN, AbilityIconSize = -100, NextSizeRatio = float.PositiveInfinity };
config.Normalize();
Check(config.GcdIconSize == 40 && config.AbilityIconSize == 8 && config.NextSizeRatio == 1.5f, "Normalizes invalid saved dimensions");
Console.WriteLine($"PASS: {checks} bridge, action, settings, visibility and lifecycle checks.");

internal static class OldQueue
{
    public static IAction? Action;
    public static double Duration;
    public static void AddCommandAction(IAction action, double time) { Action = action; Duration = time; }
}

internal static class IncompatibleQueue
{
    public static void AddCommandAction(IAction action, double time, int requiredTarget) { }
}
