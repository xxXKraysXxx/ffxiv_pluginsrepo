using Dalamud.Interface.Windowing;

namespace RSRClassicPanel;

internal enum LifestreamColumn { Aethernet, ResidentialMain, ResidentialSubdivision, Custom, Worlds, Wards, Instances }

internal readonly record struct LifestreamLayout(string UseState, bool Aethernet, bool Mini, bool Worlds,
    bool Wards, bool Instances, bool WorldAetheryte, bool HousingAetheryte, bool CanShowInstances)
{
    public List<LifestreamColumn> Columns()
    {
        List<LifestreamColumn> result = [];
        switch (UseState)
        {
            case "Normal":
                if (Aethernet) result.Add(LifestreamColumn.Aethernet);
                if (Worlds && WorldAetheryte) result.Add(LifestreamColumn.Worlds);
                if (Wards && HousingAetheryte) result.Add(LifestreamColumn.Wards);
                break;
            case "Residential" when Aethernet && Mini:
                result.Add(LifestreamColumn.ResidentialMain); result.Add(LifestreamColumn.ResidentialSubdivision);
                break;
            case "Custom" when Aethernet: result.Add(LifestreamColumn.Custom); break;
        }
        if (Instances && CanShowInstances) result.Add(LifestreamColumn.Instances);
        return result;
    }
}

internal sealed class LifestreamClassicWindow(LifestreamBridge bridge, Func<(string Home, string Current)> playerWorlds,
    Action<Exception> fail) : Window(bridge.Stock.WindowName,
        ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoFocusOnAppearing, true)
{
    private List<LifestreamColumn> columns = [];
    private bool preDrawApplied;
    public override void OnClose() => bridge.Stock.IsOpen = false;
    public override bool DrawConditions()
    {
        try
        {
            if (!bridge.Bool("Enable") || bridge.Busy || bridge.Occupied || bridge.DisallowedAethernet) return false;
            var state = bridge.UseState;
            if (state == "None") bridge.ResetWidth();
            columns = new LifestreamLayout(state, bridge.Bool("ShowAethernet"), bridge.Bool("ShowMiniAetheryteOverlay"),
                bridge.Bool("ShowWorldVisit"), bridge.Bool("ShowWards"), bridge.Bool("ShowInstanceSwitcher"),
                bridge.WorldAetheryte, bridge.HousingAetheryte,
                bridge.CurrentInstance != 0 && (bridge.Active == null || bridge.Access.Read<bool>(bridge.Active, "IsAetheryte")) &&
                    bridge.CanChangeInstance).Columns();
            RespectCloseHotkey = bridge.Bool("AllowClosingESC2");
            return columns.Count > 0 && !bridge.HiddenByGameWindow;
        }
        catch (Exception e) { fail(e); return false; }
    }
    public override void PreDraw()
    {
        try { bridge.Stock.PreDraw(); preDrawApplied = true; }
        catch (Exception e) { fail(e); }
    }
    public override void PostDraw()
    {
        try
        {
            if (preDrawApplied) { preDrawApplied = false; bridge.Stock.PostDraw(); }
            // WindowHost applies the close button/Escape before PostDraw and calls OnClose next frame.
            // Mirror the close now so the next connection tick cannot reopen the window prematurely.
            bridge.Stock.IsOpen = IsOpen;
        }
        catch (Exception e) { fail(e); }
    }
    public override void Draw()
    {
        try
        {
            if (columns.Count == 1) DrawColumn(columns[0]);
            else if (ImGui.BeginTable("LifestreamTable", Math.Max(1, columns.Count), ImGuiTableFlags.NoSavedSettings))
            {
                try { foreach (var column in columns) { ImGui.TableNextColumn(); DrawColumn(column); } }
                finally { ImGui.EndTable(); }
            }
            bridge.FinishDraw(ImGui.GetWindowSize());
        }
        catch (Exception e) { fail(e); }
    }
    private void DrawColumn(LifestreamColumn column)
    {
        switch (column)
        {
            case LifestreamColumn.Aethernet: bridge.DrawPart("DrawNormalAethernet"); break;
            case LifestreamColumn.Custom: bridge.DrawPart("DrawCustomAethernet"); break;
            case LifestreamColumn.ResidentialMain: bridge.DrawPart("DrawResidentialAethernet", false); break;
            case LifestreamColumn.ResidentialSubdivision: bridge.DrawPart("DrawResidentialAethernet", true); break;
            case LifestreamColumn.Instances: bridge.DrawPart("DrawInstances"); break;
            case LifestreamColumn.Worlds: DrawWorlds(); break;
            case LifestreamColumn.Wards: DrawWards(); break;
        }
    }
    private string Pad => new(' ', Math.Clamp(bridge.Int("LeftAlignPadding"), 0, 20));
    private void DrawWorlds()
    {
        var (home, current) = playerWorlds();
        foreach (var world in bridge.Worlds)
        {
            var label = Pad + (world == home ? "\ue048 " : "") + world;
            bridge.Resize(label);
            ImGui.BeginDisabled(world == current || bridge.Busy || bridge.DisallowedWorld);
            try { if (ImGui.Button(label, bridge.Size(1, "ButtonHeightWorld"))) bridge.VisitWorld(world); }
            finally { ImGui.EndDisabled(); }
        }
    }
    private void DrawWards()
    {
        for (var ward = 1; ward <= 30; ward++)
        {
            var label = Pad + ward;
            bridge.Resize(label);
            var width = (bridge.Size(2, "InstanceButtonHeight").X - ImGui.GetStyle().ItemSpacing.X * 2) / 3;
            if (ImGui.Button(label + "##ward", new Vector2(width, bridge.Size(1, "ButtonHeightWorld").Y))) bridge.VisitWard(ward);
            if (ward % 3 != 0) ImGui.SameLine();
        }
    }
}
