namespace RSRClassicPanel;

// Roll back in reverse order, including when installation fails halfway through.
internal sealed class UiReplacementLease : IDisposable
{
    private readonly Stack<Action> undo = [];
    public static UiReplacementLease Replace(Dalamud.Interface.Windowing.WindowSystem windows,
        Dalamud.Interface.Windowing.Window stock, Dalamud.Interface.Windowing.Window classic,
        Action hideBadges, Action showBadges, Func<bool> isCurrent)
    {
        var lease = new UiReplacementLease();
        lease.Apply(hideBadges, () => { if (isCurrent()) showBadges(); });
        lease.Apply(() => windows.RemoveWindow(stock),
            () => { if (isCurrent() && !windows.Windows.Contains(stock)) windows.AddWindow(stock); });
        lease.Apply(() => windows.AddWindow(classic),
            () => { if (windows.Windows.Contains(classic)) windows.RemoveWindow(classic); });
        return lease;
    }
    public void Apply(Action enable, Action disable)
    {
        undo.Push(disable);
        try { enable(); }
        catch { Dispose(); throw; }
    }
    public void Dispose()
    {
        List<Exception> errors = [];
        while (undo.TryPop(out var action))
            try { action(); } catch (Exception error) { errors.Add(error); }
        if (errors.Count > 0) throw new AggregateException("Could not fully restore the original UI.", errors);
    }
}
