using System.Collections;
using System.Reflection;
using Dalamud.Interface.Windowing;

namespace RSRClassicPanel;

// Bind only to the installed plugin. Its renderers retain favorites, renames and current travel logic.
internal sealed class LifestreamBridge
{
    internal readonly ReflectionAccess Access = new();
    private readonly Dictionary<string, MethodInfo> methods = [];
    private readonly Dictionary<string, Type> types = [];
    public Assembly Assembly { get; }
    public bool HasBadges { get; }
    private Type T(string name) => types.TryGetValue(name, out var type) ? type :
        types[name] = Assembly.GetType("Lifestream." + name, true)!;
    private object? Get(string type, string member) => Access.Get(T(type), member);
    public object Config => Get("Lifestream", "C")!;
    public object Instance => Get("Lifestream", "P")!;
    public object Instances => Get("Services.Service", "InstanceHandler")!;
    public Window Stock => (Window)Get("Services.Service+Gui", "Overlay")!;
    public WindowSystem Windows => (WindowSystem)Access.Get(EzGui, "WindowSystem")!;
    private Type EzGui => Ecommons.GetType("ECommons.SimpleGui.EzConfigGui", true)!;
    public Assembly Ecommons { get; }
    public bool Ready => Config != null && Get("Services.Service+Gui", "Overlay") != null &&
        Access.Get(EzGui, "WindowSystem") != null && Get("Services.Service+Gui", "BadgeOverlayManager") is { } manager &&
        Access.Get(manager, "Overlay") != null;
    public bool Bool(string name) => Access.Read<bool>(Config, name);
    public int Int(string name) => Access.Read<int>(Config, name);
    public object? Active => Access.Get(Instance, "ActiveAetheryte");
    public uint Territory => Access.Read<uint>(Instance, "Territory");
    public string UseState => Call("CanUseAetheryte")!.ToString()!;
    public bool Busy => (bool)Call("IsBusy")!;
    public bool DisallowedWorld => (bool)Call("IsDisallowedToChangeWorld")!;
    public bool WorldAetheryte => Active is { } active && (bool)Call("IsWorldChangeAetheryte", active)!;
    public bool HousingAetheryte => Active is { } active && (bool)Call("IsResidentialAetheryte", active)! &&
        ((IEnumerable)Access.Get(T("Utils"), "HousingAethernet")!).Cast<object>().Any(x => Convert.ToUInt32(x) == Territory);
    public int CurrentInstance => (int)CallOn(Instances, "GetInstance")!;
    public bool CanChangeInstance => (bool)CallOn(Instances, "CanChangeInstance")!;
    public bool HiddenByGameWindow => Bool("HideAddon") && (bool)Call("IsAddonsVisible", Access.Get(Config, "HideAddonList"))!;
    public bool DisallowedAethernet => (bool)Call("IsDisallowedToUseAethernet")!;
    public bool Occupied => (bool)methods["IsOccupied"].Invoke(null, null)!;
    public IEnumerable<string> Worlds => ((IEnumerable)Access.Get(Get("Services.Service+Data", "DataStore")!, "Worlds")!).Cast<string>();
    public object? Call(string name, params object?[] args) => methods[name].Invoke(null,
        ReflectionAccess.ArgumentsWithOptionalTail(methods[name], args));
    private object? CallOn(object target, string name, params object?[] args) => methods[name].Invoke(target,
        ReflectionAccess.ArgumentsWithOptionalTail(methods[name], args));
    public void DrawPart(string name, params object?[] args) => CallOn(Stock, name, args);
    public Vector2 Size(int index, string height) => Access.Read<Vector2>(Stock, "bWidth") +
        new Vector2(Access.Read<int[]>(Config, "ButtonWidthArray")[index], Int(height));
    public void Resize(string text) => CallOn(Stock, "ResizeButton", text);
    public void FinishDraw(Vector2 size) => Access.Set(Stock, "WSize", size);
    public void ResetWidth() => Access.Set(Stock, "bWidth", new Vector2(10));

    public LifestreamBridge(Assembly assembly, Assembly ecommons)
    {
        Assembly = assembly; Ecommons = ecommons;
        HasBadges = assembly.GetType("Lifestream.Services.BadgeOverlayManager") != null;
        if (!HasBadges) return; // Older Lifestream already has the complete classic overlay.
        void Bind(string type, string name, int count, string? key = null)
        {
            var method = Access.Method(T(type), name, count);
            methods.Add(key ?? name, method);
        }
        foreach (var (type, names) in new (string, string[])[]
        {
            ("Lifestream", ["C", "P", "ActiveAetheryte", "Territory", "TaskManager"]),
            ("Services.Service", ["InstanceHandler"]),
            ("Services.Service+Gui", ["Overlay", "BadgeOverlayManager"]),
            ("Services.Service+Data", ["DataStore"]),
            ("Data.Config", ["Enable", "ShowAethernet", "ShowMiniAetheryteOverlay", "ShowWorldVisit", "ShowWards",
                "ShowInstanceSwitcher", "HideAddon", "HideAddonList", "AllowClosingESC2", "LeftAlignPadding",
                "ButtonWidthArray", "ButtonHeightWorld", "ButtonHeightAetheryte", "InstanceButtonHeight",
                "WorldVisitTPToAethernet", "WorldVisitTPTarget", "WorldVisitTPOnlyCmd"]),
            ("GUI.Overlay", ["bWidth", "WSize"]),
            ("Systems.Legacy.DataStore", ["Worlds"]),
            ("Utils", ["HousingAethernet"]),
            ("Services.BadgeOverlayManager", ["Overlay"]),
        }) foreach (var name in names) Access.Member(T(type), name);
        foreach (var name in new[] { "DrawNormalAethernet", "DrawCustomAethernet", "DrawInstances" }) Bind("GUI.Overlay", name, 0);
        Bind("GUI.Overlay", "DrawResidentialAethernet", 1);
        Bind("GUI.Overlay", "ResizeButton", 1);
        foreach (var name in new[] { "CanUseAetheryte", "IsBusy", "IsDisallowedToChangeWorld", "IsDisallowedToUseAethernet" }) Bind("Utils", name, 0);
        foreach (var name in new[] { "IsWorldChangeAetheryte", "IsResidentialAetheryte", "IsAddonsVisible" }) Bind("Utils", name, 1);
        foreach (var name in new[] { "GetInstance", "CanChangeInstance" }) Bind("Services.InstanceHandler", name, 0);
        Bind("Tasks.SameWorld.TaskGoToResidentialDistrict", "Enqueue", 1, "Ward");
        Bind("Tasks.CrossWorld.TaskChangeWorld", "Enqueue", 1, "World");
        Bind("Tasks.TaskRemoveAfkStatus", "Enqueue", 0, "RemoveAfk");
        Bind("Tasks.TaskDesktopNotification", "Enqueue", 1, "Notify");
        methods["SecondaryTeleport"] = T("Tasks.SameWorld.TaskTryTpToAethernetDestination").GetMethods(ReflectionAccess.Flags)
            .Single(m => m.Name == "Enqueue" && m.GetParameters()[0].ParameterType.FullName == "System.String" &&
                m.GetParameters().Skip(1).All(p => p.HasDefaultValue));
        methods["IsOccupied"] = Access.Method(ecommons.GetType("ECommons.GenericHelpers", true)!, "IsOccupied", 0);
        Access.Member(EzGui, "WindowSystem");
        Access.Member(ecommons.GetType("ECommons.DalamudServices.Svc", true)!, "PluginInterface");
        var player = ecommons.GetType("ECommons.GameHelpers.LegacyPlayer.Player", true)!;
        Access.Member(player, "Interactable");
        var taskMember = Access.Member(T("Lifestream"), "TaskManager");
        var taskType = taskMember is FieldInfo field ? field.FieldType : ((PropertyInfo)taskMember).PropertyType;
        foreach (var (key, firstType) in new[] { ("Wait", "System.Func`1[System.Boolean]"), ("Then", "System.Action") })
            methods[key] = taskType.GetMethods(ReflectionAccess.Flags).Single(m => m.Name == "Enqueue" &&
                m.GetParameters().Length > 0 && m.GetParameters()[0].ParameterType.ToString() == firstType &&
                m.GetParameters().Skip(1).All(p => p.HasDefaultValue));
    }

    public (object Builder, EventInfo Event, Delegate Draw) BadgeSubscription()
    {
        var manager = Get("Services.Service+Gui", "BadgeOverlayManager") ?? throw new InvalidOperationException("Lifestream is still initializing.");
        var overlay = Access.Get(manager, "Overlay")!;
        var pluginInterface = Access.Get(Ecommons.GetType("ECommons.DalamudServices.Svc", true)!, "PluginInterface")!;
        var builder = Access.Get(pluginInterface, "UiBuilder")!;
        var drawEvent = builder.GetType().GetEvent("Draw") ?? throw new MissingMemberException("Lifestream UiBuilder.Draw");
        var draw = Access.Method(overlay.GetType(), "Draw", 0).CreateDelegate(drawEvent.EventHandlerType!, overlay);
        return (builder, drawEvent, draw);
    }

    public void VisitWorld(string world)
    {
        if (Busy || DisallowedWorld || !WorldAetheryte || !Worlds.Contains(world)) return;
        Call("RemoveAfk"); Call("World", world); Call("Notify", $"Arrived to {world}");
        if (Bool("WorldVisitTPToAethernet") && !Bool("WorldVisitTPOnlyCmd") &&
            Access.Read<string>(Config, "WorldVisitTPTarget") is { Length: > 0 } target)
        {
            var tasks = Access.Get(Instance, "TaskManager")!;
            var player = Ecommons.GetType("ECommons.GameHelpers.LegacyPlayer.Player", true)!;
            Func<bool> wait = () => Access.Read<bool>(player, "Interactable");
            Action then = () => Call("SecondaryTeleport", target);
            methods["Wait"].Invoke(tasks, ReflectionAccess.ArgumentsWithOptionalTail(methods["Wait"], wait));
            methods["Then"].Invoke(tasks, ReflectionAccess.ArgumentsWithOptionalTail(methods["Then"], then));
        }
    }
    public void VisitWard(int ward)
    {
        if (ward is < 1 or > 30 || Busy || !HousingAetheryte) return;
        Call("RemoveAfk"); Call("Ward", ward);
    }
}
