using System.Numerics;

namespace Lifestream
{
    public sealed class Lifestream
    {
        public static Data.Config C = new();
        public static Lifestream P = new();
        public Data.TinyAetheryte? ActiveAetheryte = new(8, true);
        public uint Territory = 129;
        public FakeTaskManager TaskManager = new();
    }
    public sealed class FakeTaskManager
    {
        public readonly List<Delegate> Tasks = [];
        public void Enqueue(Func<bool> wait, object? configuration = null) => Tasks.Add(wait);
        public void Enqueue(Action action, object? configuration = null) => Tasks.Add(action);
    }
    public static class Utils
    {
        public static uint[] HousingAethernet = [129];
        public static bool Busy, Disallowed;
        public static string State = "Normal";
        public static bool IsBusy() => Busy;
        public static bool IsDisallowedToChangeWorld() => Disallowed;
        public static bool IsDisallowedToUseAethernet() => false;
        public static bool IsAddonsVisible(IEnumerable<string> addons) => false;
        public static string CanUseAetheryte() => State;
        public static bool IsWorldChangeAetheryte(Data.TinyAetheryte a) => a.ID == 8;
        public static bool IsResidentialAetheryte(Data.TinyAetheryte a) => a.ID == 8;
    }
    public sealed class FakeUiBuilder
    {
        public event Action? Draw;
        public void Render() => Draw?.Invoke();
    }
    public sealed class FakePluginInterface { public FakeUiBuilder UiBuilder { get; } = new(); }
}
namespace Lifestream.Data
{
    public readonly record struct TinyAetheryte(uint ID, bool IsAetheryte);
    public sealed class Config
    {
        public bool Enable = true, ShowAethernet = true, ShowMiniAetheryteOverlay = true, ShowWorldVisit = true,
            ShowWards = true, ShowInstanceSwitcher = true, HideAddon = true, AllowClosingESC2,
            WorldVisitTPToAethernet = true, WorldVisitTPOnlyCmd;
        public HashSet<string> HideAddonList = [];
        public int LeftAlignPadding, ButtonHeightWorld = 5, ButtonHeightAetheryte = 1, InstanceButtonHeight = 10;
        public int[] ButtonWidthArray = [10, 10, 10];
        public string WorldVisitTPTarget = "Market";
    }
}
namespace Lifestream.Services
{
    public static class Service
    {
        public static InstanceHandler InstanceHandler = new();
        public static class Gui
        {
            public static GUI.Overlay Overlay = new();
            public static BadgeOverlayManager BadgeOverlayManager = new();
        }
        public static class Data { public static Systems.Legacy.DataStore DataStore = new(); }
    }
    public sealed class InstanceHandler
    {
        public int GetInstance() => 1;
        public bool CanChangeInstance() => true;
    }
    public sealed class BadgeOverlayManager { public FakeBadgeOverlay Overlay = new(); }
    public sealed class FakeBadgeOverlay
    {
        public int Draws;
        public void Draw() => Draws++;
    }
}
namespace Lifestream.Systems.Legacy
{
    public sealed class DataStore { public string[] Worlds = ["Alpha", "Beta"]; }
}
namespace Lifestream.GUI
{
    public sealed class Overlay() : Dalamud.Interface.Windowing.Window("Lifestream Overlay")
    {
        public Vector2 bWidth = new(10), WSize = new(200);
        public readonly List<bool?> Subdivisions = [];
        public override void Draw() { }
        public void DrawNormalAethernet() { }
        public void DrawCustomAethernet() { }
        public void DrawInstances() { }
        public void DrawResidentialAethernet(bool? subdivision = null) => Subdivisions.Add(subdivision);
        public void ResizeButton(string text) { }
    }
}
namespace Lifestream.Tasks
{
    public static class Trace { public static readonly List<string> Calls = []; }
    public static class TaskRemoveAfkStatus { public static void Enqueue() => Trace.Calls.Add("afk"); }
    public static class TaskDesktopNotification { public static void Enqueue(string text) => Trace.Calls.Add(text); }
}
namespace Lifestream.Tasks.CrossWorld
{
    public static class TaskChangeWorld { public static void Enqueue(string world) => Tasks.Trace.Calls.Add("world:" + world); }
}
namespace Lifestream.Tasks.SameWorld
{
    public static class TaskGoToResidentialDistrict { public static void Enqueue(int ward) => Tasks.Trace.Calls.Add("ward:" + ward); }
    public static class TaskTryTpToAethernetDestination
    {
        public static void Enqueue(string targetName, bool allowPartial = false, bool allowTpFallback = false, bool retry = false)
        {
            if (allowPartial || allowTpFallback || retry) throw new Exception("Unexpected override of native defaults");
            Tasks.Trace.Calls.Add("aethernet:" + targetName);
        }
    }
}
namespace ECommons
{
    public static class GenericHelpers { public static bool IsOccupied() => false; }
}
namespace ECommons.SimpleGui
{
    public static class EzConfigGui { public static object? WindowSystem; }
}
namespace ECommons.DalamudServices
{
    public static class Svc { public static Lifestream.FakePluginInterface PluginInterface = new(); }
}
namespace ECommons.GameHelpers.LegacyPlayer
{
    public static class Player { public static bool Interactable { get; set; } }
}
