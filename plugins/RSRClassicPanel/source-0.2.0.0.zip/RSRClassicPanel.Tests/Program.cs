using System.Reflection;
using RSRClassicPanel;
using RotationSolver.Basic;
using RotationSolver.Basic.Actions;
using RsrData = RotationSolver.Basic.DataCenter;
using Service = RotationSolver.Basic.Service;

var checks = 0;
void Check(bool condition, string name) { if (!condition) throw new Exception(name); checks++; }
var commands = new List<string>();
var loaded = true;
var bridge = new RsrBridge(commands.Add);
bridge.AttachTypes(Assembly.GetExecutingAssembly(), Assembly.GetExecutingAssembly(), () => loaded);
Check(bridge.IsCurrent, "Connects to fake live RSR");
Check(bridge.ValidForPanel && bridge.VisibleByRsrRules(), "Respects current rotation and normal visibility");
Service.Config.OnlyShowWithHostileOrInDuty.Value = true;
Check(!bridge.VisibleByRsrRules(), "Hides outside duty without enemies");
Service.Config.OnlyShowWithHostileOrInDuty.Value = false;
var action = new FakeAction();
var view = bridge.Wrap(action)!;
Check(view.Name == "Test GCD" && view.Cooldown.MaxCharges == 2, "Reads names and boxed cooldown structs");
Check(view == bridge.Wrap(action), "Action wrappers preserve identity");
bridge.ClickAction(view);
Check(action.Uses == 1 && action.ForceObserved && action.FlagsObserved, "Off-mode action click matches original CanUse options");
Check(!IBaseAction.ForceEnable, "ForceEnable restored after click");
IBaseAction.ForceEnable = true;
bridge.ClickAction(view);
Check(IBaseAction.ForceEnable, "Preserves a pre-existing ForceEnable value");
IBaseAction.ForceEnable = false;
action.ThrowOnCheck = true;
try { bridge.ClickAction(view); throw new Exception("Expected failed check"); }
catch (TargetInvocationException) { Check(!IBaseAction.ForceEnable, "Restores ForceEnable when CanUse throws"); }
action.ThrowOnCheck = false;
action.Usable = false;
var uses = action.Uses;
bridge.ClickAction(view);
Check(action.Uses == uses, "Does not use unavailable actions");
RsrData.State = true;
bridge.ClickAction(view);
Check(ReferenceEquals(RsrData.CommandNextAction, action) && RsrData.CommandDuration == 5 && action.Uses == uses,
    "Active-mode click queues a five-second command without executing directly");
Check(RsrData.CommandTarget == null, "New queue signature preserves RSR's default target selection");
var access = new ReflectionAccess();
var oldQueueMethod = access.MethodWithOptionalTail(typeof(OldQueue), "AddCommandAction", typeof(IAction), typeof(double));
oldQueueMethod.Invoke(null, ReflectionAccess.ArgumentsWithOptionalTail(oldQueueMethod, action, 5d));
Check(ReferenceEquals(OldQueue.Action, action) && OldQueue.Duration == 5, "Legacy two-argument queue remains compatible");
try
{
    access.MethodWithOptionalTail(typeof(IncompatibleQueue), "AddCommandAction", typeof(IAction), typeof(double));
    throw new Exception("Expected rejection of a new required argument");
}
catch (InvalidOperationException) { Check(true, "Rejects an unknown required queue argument"); }
RsrData.State = false;
var item = new FakeItem();
bridge.ClickAction(bridge.Wrap(item)!);
Check(item.Uses == 1 && item.ClippingObserved, "Off-mode item click checks clipping and uses the item");
bridge.Setting("AoEType", "Off");
Check(commands.Last() == "/rotation Settings AoEType Off" && Service.Config.Saves == 1, "Changes settings through the RSR command and saves");
RsrData.IsPvP = true;
var commandCount = commands.Count;
bridge.Command("/rotation Auto");
bridge.ClickAction(view);
Check(commands.Count == commandCount && action.Uses == uses, "Blocks action commands in PvP");
RsrData.IsPvP = false;
bridge.SetDrawing(true);
Check(RsrData.DrawingActions, "Requests live preview icons");
RotationSolver.RotationSolverPlugin._fullControlWindow.IsOpen = true;
bridge.SetDrawing(false);
Check(RsrData.DrawingActions, "Keeps previews for an open stock panel");
RotationSolver.RotationSolverPlugin._fullControlWindow.IsOpen = false;
bridge.SetDrawing(false);
Check(!RsrData.DrawingActions, "Releases previews when both panels close");
Check(bridge.Description("Auto", false) == "Automatic mode" && bridge.Description("HealArea", true) == "Area heal", "Reads RSR's own tooltip descriptions");
Service.Config.TargetingIndex = 0;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1 && bridge.Data("TargetingType")!.ToString() == "HighHP" && !RsrData.State,
    "Targeting cycle follows the configured list without enabling autorotation");
Service.Config.TargetingIndex = 3;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 0, "Targeting cycle wraps to the first mode");
Service.Config.TargetingTypes = ["Big", "Small"];
RsrData.State = RsrData.IsManual = true;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1 && RsrData.State && RsrData.IsManual, "Targeting cycle respects custom order and preserves Manual mode");
RsrData.State = RsrData.IsManual = false;
RsrData.IsPvP = true;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Targeting cycle does not change PvP settings");
RsrData.IsPvP = false;
Service.Config.TargetingTypes.Clear();
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Empty targeting list is a safe no-op");
loaded = false;
bridge.CycleTargeting();
Check(Service.Config.TargetingIndex == 1, "Targeting cycle ignores an unloaded RSR");
bridge.Command("/rotation Auto");
Check(!bridge.IsCurrent && commands.Count == commandCount, "Ignores commands after RSR unloads");
bridge.Detach();
Check(!bridge.Connected && !bridge.IsCurrent, "Detach clears connection");
loaded = true;
bridge.AttachTypes(Assembly.GetExecutingAssembly(), Assembly.GetExecutingAssembly(), () => loaded);
Check(bridge.IsCurrent, "Reconnects after reload");
bridge.Fail(new InvalidOperationException("test disconnect"));
Check(!bridge.Connected && bridge.Status.Contains("test disconnect"), "Reports bridge failure and disables commands");
var config = new Configuration { GcdIconSize = float.NaN, AbilityIconSize = -100, NextSizeRatio = float.PositiveInfinity };
config.Normalize();
Check(config.GcdIconSize == 40 && config.AbilityIconSize == 8 && config.NextSizeRatio == 1.5f, "Normalizes invalid saved dimensions");
Check(config.RestoreLifestream, "Lifestream replacement defaults to enabled for existing configurations");
var layout = new LifestreamLayout("Normal", true, true, true, true, true, true, true, true);
Check(layout.Columns().SequenceEqual(new[] { LifestreamColumn.Aethernet, LifestreamColumn.Worlds, LifestreamColumn.Wards, LifestreamColumn.Instances }),
    "Classic layout restores world and ward columns in their original order");
Check((layout with { Aethernet = false }).Columns().Contains(LifestreamColumn.Worlds), "World-only overlay remains usable");
Check((layout with { WorldAetheryte = false, HousingAetheryte = false, CanShowInstances = false }).Columns()
    .SequenceEqual(new[] { LifestreamColumn.Aethernet }), "Location rules hide unavailable world, ward and instance controls");
Check((layout with { UseState = "Residential", CanShowInstances = false }).Columns()
    .SequenceEqual(new[] { LifestreamColumn.ResidentialMain, LifestreamColumn.ResidentialSubdivision }), "Housing uses two classic aethernet columns");
Check((layout with { UseState = "Residential", Mini = false, CanShowInstances = false }).Columns().Count == 0,
    "Respects miniature aetheryte overlay preference");
Check((layout with { UseState = "Custom", CanShowInstances = false }).Columns().SequenceEqual(new[] { LifestreamColumn.Custom }),
    "Custom zones use current Lifestream's aethernet renderer");
Check((layout with { UseState = "None" }).Columns().SequenceEqual(new[] { LifestreamColumn.Instances }), "Instance-only overlay works without nearby aethernet");
Check((layout with { UseState = "None", Instances = false }).Columns().Count == 0, "No empty window when all available sections are disabled");
var lifecycle = new List<string>();
var uiLease = new UiReplacementLease();
uiLease.Apply(() => lifecycle.Add("hide badges"), () => lifecycle.Add("restore badges"));
uiLease.Apply(() => lifecycle.Add("remove stock"), () => lifecycle.Add("restore stock"));
uiLease.Apply(() => lifecycle.Add("add classic"), () => lifecycle.Add("remove classic"));
uiLease.Dispose();
Check(lifecycle.SequenceEqual(new[] { "hide badges", "remove stock", "add classic", "remove classic", "restore stock", "restore badges" }),
    "Disabling replacement restores stock windows and badges in reverse order");
uiLease.Dispose();
Check(lifecycle.Count == 6, "Repeated disposal cannot duplicate stock windows or badge handlers");
lifecycle.Clear();
var partialLease = new UiReplacementLease();
partialLease.Apply(() => lifecycle.Add("hide badges"), () => lifecycle.Add("restore badges"));
try
{
    partialLease.Apply(() => throw new InvalidOperationException("registration failed"), () => lifecycle.Add("restore stock"));
}
catch (InvalidOperationException) { }
Check(lifecycle.SequenceEqual(new[] { "hide badges", "restore stock", "restore badges" }), "Partial installation failure rolls back all UI changes");
lifecycle.Clear();
var brokenLease = new UiReplacementLease();
brokenLease.Apply(() => { }, () => lifecycle.Add("restore badges"));
brokenLease.Apply(() => { }, () => throw new InvalidOperationException("window unloaded"));
try { brokenLease.Dispose(); } catch (AggregateException) { }
Check(lifecycle.SequenceEqual(new[] { "restore badges" }), "Restoration continues if one unloaded resource throws");
var ls = new LifestreamBridge(Assembly.GetExecutingAssembly(), Assembly.GetExecutingAssembly());
Check(!ls.Ready, "Waits for Lifestream's deferred UI initialization before making changes");
ECommons.SimpleGui.EzConfigGui.WindowSystem = new object();
Check(ls.Ready, "Detects initialized Lifestream resources on a later frame");
ls.DrawPart("DrawResidentialAethernet", false);
ls.DrawPart("DrawResidentialAethernet", true);
Check(Lifestream.Services.Service.Gui.Overlay.Subdivisions.SequenceEqual(new bool?[] { false, true }),
    "Invokes native residential renderer with correctly boxed nullable subdivision arguments");
ls.FinishDraw(new System.Numerics.Vector2(500, 300));
Check(Lifestream.Services.Service.Gui.Overlay.WSize == new System.Numerics.Vector2(500, 300),
    "Native fixed-position calculations receive the restored window's current dimensions");
Exception? renderError = null;
var lsWindow = new LifestreamClassicWindow(ls, () => ("Alpha", "Beta"), e => renderError = e);
Check(lsWindow.DrawConditions() && lsWindow.ForceMainWindow, "Restored overlay uses current location rules and the game's main viewport");
Lifestream.Lifestream.C.Enable = false;
Check(!lsWindow.DrawConditions(), "Replacement respects the user's global Lifestream enable setting");
Lifestream.Lifestream.C.Enable = true;
Lifestream.Utils.Busy = true;
Check(!lsWindow.DrawConditions(), "Classic window stays hidden while Lifestream is executing travel");
Lifestream.Utils.Busy = false;
Lifestream.Services.Service.Gui.Overlay.IsOpen = true;
lsWindow.IsOpen = false;
lsWindow.PostDraw();
Check(!Lifestream.Services.Service.Gui.Overlay.IsOpen && renderError == null,
    "Close-button/Escape state reaches the native window before the next synchronization tick");
var lsCalls = Lifestream.Tasks.Trace.Calls;
ls.VisitWorld("Alpha");
Check(lsCalls.SequenceEqual(new[] { "afk", "world:Alpha", "Arrived to Alpha" }), "World button invokes native travel and notification routines");
var lsTasks = Lifestream.Lifestream.P.TaskManager.Tasks;
Check(lsTasks.Count == 2 && lsTasks[0] is Func<bool> && lsTasks[1] is Action, "Post-world teleport waits for interactable state before queuing aethernet travel");
Check(!((Func<bool>)lsTasks[0])(), "Post-world wait does not complete during loading");
ECommons.GameHelpers.LegacyPlayer.Player.Interactable = true;
Check(((Func<bool>)lsTasks[0])(), "Post-world wait completes once player is interactable");
((Action)lsTasks[1])();
Check(lsCalls.Last() == "aethernet:Market", "Secondary aethernet teleport preserves native optional defaults");
lsCalls.Clear(); lsTasks.Clear();
Lifestream.Lifestream.C.WorldVisitTPOnlyCmd = true;
ls.VisitWorld("Beta");
Check(lsTasks.Count == 0, "Overlay respects command-only secondary teleport preference");
lsCalls.Clear();
Lifestream.Utils.Busy = true;
ls.VisitWorld("Alpha"); ls.VisitWard(5);
Check(lsCalls.Count == 0, "Busy guard blocks duplicate world and ward travel");
Lifestream.Utils.Busy = false; Lifestream.Utils.Disallowed = true;
ls.VisitWorld("Alpha");
Check(lsCalls.Count == 0, "World travel respects Lifestream's party and duty restrictions");
Lifestream.Utils.Disallowed = false;
ls.VisitWorld("Unknown"); ls.VisitWard(0); ls.VisitWard(31);
Check(lsCalls.Count == 0, "Rejects unknown worlds and invalid wards");
Lifestream.Lifestream.P.ActiveAetheryte = new Lifestream.Data.TinyAetheryte(999, true);
ls.VisitWorld("Alpha"); ls.VisitWard(5);
Check(lsCalls.Count == 0, "World and ward actions require a suitable nearby aetheryte");
Lifestream.Lifestream.P.ActiveAetheryte = new Lifestream.Data.TinyAetheryte(8, true);
ls.VisitWard(5);
Check(lsCalls.SequenceEqual(new[] { "afk", "ward:5" }), "Ward button passes the original one-based ward index to native travel");
var badge = ls.BadgeSubscription();
var fakeUi = ECommons.DalamudServices.Svc.PluginInterface.UiBuilder;
fakeUi.Draw += Lifestream.Services.Service.Gui.BadgeOverlayManager.Overlay.Draw;
fakeUi.Render();
using (var badgeLease = new UiReplacementLease())
{
    badgeLease.Apply(() => badge.Event.RemoveEventHandler(badge.Builder, badge.Draw), () => badge.Event.AddEventHandler(badge.Builder, badge.Draw));
    fakeUi.Render();
    Check(Lifestream.Services.Service.Gui.BadgeOverlayManager.Overlay.Draws == 1, "Suppresses the real instance's existing badge draw delegate");
}
fakeUi.Render();
Check(Lifestream.Services.Service.Gui.BadgeOverlayManager.Overlay.Draws == 2, "Restores the badge draw delegate when toggled off");
var nativeWindows = new Dalamud.Interface.Windowing.WindowSystem("LifestreamTest");
var originalWindow = new TestWindow("Lifestream Overlay");
var classicWindow = new TestWindow("Lifestream Overlay");
nativeWindows.AddWindow(originalWindow);
var badgesVisible = true;
var windowLease = UiReplacementLease.Replace(nativeWindows, originalWindow, classicWindow,
    () => badgesVisible = false, () => badgesVisible = true, () => true);
Check(!badgesVisible && nativeWindows.Windows.Count == 1 && nativeWindows.Windows.Single() == classicWindow,
    "Enabled replacement registers exactly one classic window under the original name");
windowLease.Dispose();
Check(badgesVisible && nativeWindows.Windows.Count == 1 && nativeWindows.Windows.Single() == originalWindow,
    "Toggle off restores the exact original window object and badges");
using (UiReplacementLease.Replace(nativeWindows, originalWindow, classicWindow,
    () => badgesVisible = false, () => badgesVisible = true, () => true)) { }
Check(nativeWindows.Windows.Count == 1 && badgesVisible, "Repeated toggles do not accumulate windows or handlers");
var pluginStillLoaded = true;
var unloadingLease = UiReplacementLease.Replace(nativeWindows, originalWindow, classicWindow,
    () => badgesVisible = false, () => badgesVisible = true, () => pluginStillLoaded);
pluginStillLoaded = false;
nativeWindows.RemoveAllWindows();
unloadingLease.Dispose();
Check(nativeWindows.Windows.Count == 0 && !badgesVisible, "Lifestream unload does not resurrect disposed UI or reattach handlers");
nativeWindows.AddWindow(originalWindow);
var conflictingWindow = new TestWindow("Conflicting");
nativeWindows.AddWindow(conflictingWindow);
try
{
    UiReplacementLease.Replace(nativeWindows, originalWindow, new TestWindow("Conflicting"),
        () => badgesVisible = false, () => badgesVisible = true, () => true);
}
catch (ArgumentException) { }
Check(badgesVisible && nativeWindows.Windows.Count == 2 && nativeWindows.Windows.Contains(originalWindow) &&
    nativeWindows.Windows.Contains(conflictingWindow), "Failed window registration rolls back without deleting unrelated windows");
if (args.Length > 0)
{
    var lifestreamPath = Path.GetFullPath(args[0]);
    var hooks = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XIVLauncher/addon/Hooks/15.0.3.6");
    var runtime = Path.GetDirectoryName(typeof(object).Assembly.Location)!;
    var paths = Directory.GetFiles(runtime, "*.dll").Concat(Directory.GetFiles(hooks, "*.dll"))
        .Concat(Directory.GetFiles(lifestreamPath, "*.dll")).GroupBy(Path.GetFileName).Select(g => g.Last());
    using var metadata = new MetadataLoadContext(new PathAssemblyResolver(paths));
    var realAssembly = metadata.LoadFromAssemblyPath(Path.Combine(lifestreamPath, "Lifestream.dll"));
    var realEcommons = metadata.LoadFromAssemblyPath(Path.Combine(lifestreamPath, "ECommons.dll"));
    var realContract = new LifestreamBridge(realAssembly, realEcommons);
    Check(realContract.HasBadges, "Detects badge UI in actual latest Lifestream release");
    var badgeManager = realAssembly.GetType("Lifestream.Services.BadgeOverlayManager", true)!;
    var badgeOverlay = realContract.Access.Member(badgeManager, "Overlay");
    var overlayType = badgeOverlay is FieldInfo overlayField ? overlayField.FieldType : ((PropertyInfo)badgeOverlay).PropertyType;
    Check(overlayType.GetMethod("Draw", Type.EmptyTypes)?.ReturnType.FullName == "System.Void", "Badge overlay uses a parameterless draw callback");
    Check(realAssembly.GetType("Lifestream.GUI.MainGui", true)!.BaseType!.Assembly == realEcommons,
        "Finds the correct live ECommons assembly through MainGui's base type");
    Console.WriteLine($"PASS: all classic overlay adapter members bind against Lifestream {realAssembly.GetName().Version}.");
}
if (args.Length > 1)
{
    var oldPath = Path.GetFullPath(args[1]);
    var runtime = Path.GetDirectoryName(typeof(object).Assembly.Location)!;
    var hooks = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XIVLauncher/addon/Hooks/15.0.3.6");
    var paths = Directory.GetFiles(runtime, "*.dll").Concat(Directory.GetFiles(hooks, "*.dll"))
        .Concat(Directory.GetFiles(oldPath, "*.dll")).GroupBy(Path.GetFileName).Select(g => g.Last());
    using var oldMetadata = new MetadataLoadContext(new PathAssemblyResolver(paths));
    var oldAssembly = oldMetadata.LoadFromAssemblyPath(Path.Combine(oldPath, "Lifestream.dll"));
    var oldEcommons = oldMetadata.LoadFromAssemblyPath(Path.Combine(oldPath, "ECommons.dll"));
    Check(!new LifestreamBridge(oldAssembly, oldEcommons).HasBadges, "Installed pre-badge Lifestream is left on its original classic UI");
}
Console.WriteLine($"PASS: {checks} bridge, action, settings, layout and lifecycle checks.");

internal static class OldQueue
{
    public static IAction? Action;
    public static double Duration;
    public static void AddCommandAction(IAction action, double time) { Action = action; Duration = time; }
}

internal static class IncompatibleQueue
{
    public static void AddCommandAction(IAction action, double time, int requiredTarget) { }
}

internal sealed class TestWindow(string name) : Dalamud.Interface.Windowing.Window(name)
{
    public override void Draw() { }
}
